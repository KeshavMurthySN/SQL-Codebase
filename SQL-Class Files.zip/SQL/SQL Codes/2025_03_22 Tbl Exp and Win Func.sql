/* 
Topics for today
		> Query Designer (GUI)
		> Table Expressions:
			 - Derived Tables
			 - Common Table Expressions (CTE)
			 - Views
			 - Table Valued Functions (TVF) - will be covered later
		> Windows Function
		> Temp Tables
		> Removing duplicate rows
*/


use HR_2


-- inspect employee table
select * from employees


-- Categorise employees as follows - if salary is greater than 8000 then high else low
select 
	employee_id,
	email,
	salary,
	IIF(salary > 8000, 'High', 'Low') as SalCategory
from employees



-- Categorise employees as - if salary is GT 15000 then High, if GT 8000 then Mid else Low
select
	employee_id,
	email,
	salary,
	(CASE
		when salary > 15000 then 'High'
		when salary > 8000 then 'Mid'
		else 'Low'
	END) as SalaryCategory
from employees


-----------------------------------------------------------------
-- Table Expressions
-----------------------------------------------------------------
/*
A table expression is a query that represents a valid relational table. 

T-SQL supports four types of table expressions: 
	derived tables
	common table expressions (CTEs)
	views
	Table-valued functions (TVFs)

These kind of queries must meet three requirements:
	1) Order is not guaranteed (No Order By)
	2) All columns must have names
	3) All column names must be unique

Benefits:
	> Table expressions allow you to decompose complex queries into smaller, more manageable parts.
	> Table expressions can store and name intermediate results, making it easier to perform subsequent operations on those results.
	> They are very useful for filtering and transforming data before it is used in the final select statement.

*/


/* Derived Tables
Derived tables (also known as table subqueries) are defined in the FROM clause of an outer query.
Inner query defines the derived table within parentheses, followed by the AS clause and the derived table name.
*/


-- Lets look at the query we wrote before
select 
	employee_id,
	email,
	salary,
	IIF(salary > 8000, 'High', 'Low') as SalCategory
from employees


-- Count how many employees are in High and Low SalCategory
select SalCategory, count(*) from
(select 
	employee_id,
	email,
	salary,
	IIF(salary > 8000, 'High', 'Low') as SalCategory
from employees) as x
group by SalCategory;



/*
Common table expressions (CTEs) are another standard form of table expression similar to derived tables.
CTEs are defined by using a WITH statement.
*/

with x as
(
	select 
		employee_id,
		email,
		salary,
		IIF(salary > 8000, 'High', 'Low') as SalCategory
	from employees
)
		
select SalCategory, count(*) 
from x
group by SalCategory


/*
When working with SQL Server, both Common Table Expressions (CTEs) and derived tables serve the purpose of creating temporary result sets for use within a larger query. Here's a breakdown of their key differences:

CTEs:
	> Defined using the WITH keyword at the beginning of a query.
	> Offer a more structured and readable approach, especially for complex queries.
	> Can be referenced multiple times within the same query.
	> Support recursive queries.

Derived Tables:
	> Subqueries placed directly within the FROM clause of a query.
	> Can sometimes lead to nested and less readable code, particularly with multiple levels.
	> Must be redefined each time they are needed.
	> Do not support recursion.

CTEs tend to be favored for their improved readability, reusability, and ability to handle recursive operations.
Derived tables are still valid and functional, but they may lead to less maintainable code in complex scenarios.
*/



/*
Derived tables and CTEs have a single-statement scope, which means they are not reusable. 
Views and table-valued functions (TVFs) are two types of table expressions whose definitions are stored as
permanent objects in the database, making them reusable.
*/


/* 
Views:

In SQL, a view is a virtual table based on the result-set of an SQL statement.

A view contains rows and columns, just like a real table. The fields in a view are fields from one or more real tables in the database.

You can add SQL statements and functions to a view and present the data as if the data were coming from one single table.

Views have the following benefits:
	> Security - Views can be made accessible to users while the underlying tables are not directly accessible. This allows the DBA to give users only the data they need, while protecting other data in the same table.
	> Simplicity - Views can be used to hide and reuse complex queries.
	> Column Name Simplification or Clarification - Views can be used to provide aliases on column names to make them more memorable and/or meaningful.
	> Stepping Stone - Views can provide a stepping stone in a "multi-level" query. 

A view is created with the CREATE VIEW statement. 
*/


-- Create a view which combines employee data from all the tables (except dependants)

drop view if exists v_FullEmpData
go
create view v_FullEmpData as
(
	select 
		employees.*, job_title, min_salary, max_salary, department_name, street_address, postal_code,
		city, state_province, country_name, region_name
	from employees
	inner join jobs on employees.job_id = jobs.job_id
	inner join departments on employees.department_id = departments.department_id
	inner join locations on departments.location_id = locations.location_id
	inner join countries on locations.country_id = countries.country_id
	inner join regions on countries.region_id = regions.region_id
)
go

-- check
select * from v_FullEmpData




----------------------------------------------------
----Windows Function:
----------------------------------------------------

/*
A window function performs a calculation across a set of table rows that are somehow related to the current row. 
This is comparable to the type of calculation that can be done with an aggregate function. 
But unlike regular aggregate functions, use of a window function does not cause rows to become 
grouped into a single output row � the rows retain their separate identities.

The key to windowing functions is in controlling the order in which the rows are evaluated

Windows functions are performed using the OVER clause.

There are three groups of functions that the OVER clause can be applied to:
	1) aggregate functions (sum, avg, max, min, etc.)
	2) ranking functions (row_number, rank, dense_rank, etc.)
	3) analytic functions (first_value, last_value, lag, lead, etc.)

*/

---------------------------------------------



-- lets look at employee id, email, salary and dept name

select employee_id, email, department_name, salary
from v_FullEmpData


-- recap of aggregate queries

select max(salary) from v_FullEmpData


select department_name, max(Salary)
from v_FullEmpData
group by department_name

-- Please note that in above queries we are losing row level details

-- If we use windows functions then we will be able to see both row level and aggregate level data together

-- Compare the salary of each employee against the salary of the highest paid person in the company

select	employee_id, email, department_name, salary,
		max(salary) over() as 'Highest_Company_Sal'
from v_FullEmpData


-- Compare the salary of each employee against the salary of the highest paid person in their respective department

select	employee_id, email, department_name, salary,
		max(salary) over(partition by department_name) as 'Highest_Dept_Sal'
from v_FullEmpData


-- Show top paid employee of each department

-- Step 1: 

select	employee_id, email, department_name, salary,
		ROW_NUMBER() over(order by salary desc) as 'rn' 
from v_FullEmpData

-- Step 2:

select	employee_id, email, department_name, salary,
		ROW_NUMBER() over(partition by department_name order by salary desc) as 'rn' 
from v_FullEmpData

-- Step 3:

select * from
(
	select	employee_id, email, department_name, salary,
			ROW_NUMBER() over(partition by department_name order by salary desc) as 'rn' 
	from v_FullEmpData) as x
where rn = 1


-- Compare row_number, rank and dense_rank

select	employee_id, email, department_name, salary,
		ROW_NUMBER() over(order by salary desc) as 'rn',
		rank() over(order by salary desc) as 'rnk',
		dense_rank() over(order by salary desc) as 'drnk'
from v_FullEmpData


-- Increase in Salary budget over time

-- Inspect the data

select employee_id, email, hire_date, salary
from v_FullEmpData
order by hire_date

-- Increase in Salary Expense over time for the whole company

select	employee_id, email, hire_date, salary,
		sum(salary) over(order by hire_date) as 'Cumulative_SalExpense'
from v_FullEmpData


-- Increase in Salary Expense over time for each department

select	employee_id, email, hire_date, department_name, salary,
		sum(salary) over(partition by department_name order by hire_date) as 'Cumulative_SalExpense'
from v_FullEmpData





-----------------------------------------------
------- Temporary Tables
-----------------------------------------------

/* 
Temporary tables can be used for storing data temporarily during a session. 

They're particularly useful for:
	> Storing intermediate results: When you have complex queries involving multiple steps, temporary tables can hold the results of each step.
	> Data manipulation: They provide a space to manipulate data before inserting it into permanent tables.

Temporary tables are stored in the tempdb system database.
These are visible only to the session that created them.
They are named with a single hash symbol (#), e.g., #MyTempTable.
They are automatically dropped when the session closes.
You can perform standard SQL operations (SELECT, INSERT, UPDATE, DELETE) on temporary tables.

*/

-- Example
use HR_2

select * 
into #test
from employees where salary > 8000

select * from #test


-----------------------------------------------
------- Removing duplicate rows
-----------------------------------------------

use Demo2

drop table if exists Employees
CREATE TABLE Employees (
    EmployeeID INT IDENTITY(1,1) PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    Department VARCHAR(50),
    Email VARCHAR(100)
);

INSERT INTO Employees (FirstName, LastName, Department, Email) VALUES
('John', 'Doe', 'Sales', 'john.doe@example.com'),
('Jane', 'Smith', 'Marketing', 'jane.smith@example.com'),
('John', 'Doe', 'Sales', 'john.doe@example.com'), -- Duplicate
('Alice', 'Johnson', 'IT', 'alice.johnson@example.com'),
('Bob', 'Williams', 'Sales', 'bob.williams@example.com'),
('Jane', 'Smith', 'Marketing', 'jane.smith@example.com'), -- Duplicate
('Charlie', 'Brown', 'IT', 'charlie.brown@example.com');

SELECT * FROM Employees;


-- Method 1: Using distinct

SELECT DISTINCT FirstName, LastName, Department, Email
INTO #TempEmployees
FROM Employees;

-- Truncate command reset the identity setup. Delete command does not
TRUNCATE TABLE Employees;

INSERT INTO Employees (FirstName, LastName, Department, Email)
SELECT FirstName, LastName, Department, Email
FROM #TempEmployees;

DROP TABLE #TempEmployees;

SELECT * FROM Employees;

-- Method 2: Use self join

DELETE E1
FROM Employees E1
JOIN Employees E2
ON E1.Email = E2.Email AND E1.Department = E2.Department
AND E1.EmployeeID > E2.EmployeeID;


-- Method 3: Use group by

DELETE FROM Employees
WHERE EmployeeID NOT IN (
    SELECT MIN(EmployeeID)
    FROM Employees
    GROUP BY Email, Department
);