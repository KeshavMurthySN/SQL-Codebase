/*
Topics for today:
	> Built In functions
		- Numeric
		- String
		- Logical
		- Date
		- Type Conversion
	> In Operator
	> Like Operator
	> Subqueries
	> Table Expressions
		- Derived Tables
		- CTE
		- Views

*/


use HR_2

select * from employees

-- Calculate Bonus which will be 1/3rd of Salary
select
	employee_id,
	email,
	salary,
	salary/3 as bonus
from employees


-- Show bonus with 1 decimal places
select
	employee_id,
	email,
	salary,
	cast(salary/3 as decimal(6,1)) as bonus
from employees


select * from employees
-- Calculate work_area, which is the first 3 digits of phone number
select 
	employee_id,
	email,
	phone_number,
	LEFT(phone_number,3) as work_area
from employees


-- If an emp does not have a phone number, mark their work_area as remote workers
select 
	employee_id,
	email,
	phone_number,
	iif(phone_number IS null, 'Remote Worker', LEFT(phone_number,3)) as work_area
from employees


-- Q: Categorise employees as follows - if salary is greater than 8000 then high else low


-- If phone number is null then mark the emp as remote worker
-- if phone number starts with 515 then mark the work_area as East
-- if phone number starts with 590 then mark the work_area as West
-- For all other cases mark the work_area as Other
select 
	employee_id,
	email,
	phone_number,
	case
		when phone_number IS null then 'Remote'
		when LEFT(phone_number,3) = '515' then 'East'
		when LEFT(phone_number,3) = '590' then 'West'
		else 'Other'
	end as work_area
from employees

-- Q: Categorise employees as - if salary is GT 15000 then High, if GT 8000 then Mid else Low


select * from employees
-- create windows_login_id for each emp. 
-- It should be a combination of last 2 chars of last_name + job_id + dept_id
select
	employee_id,
	email,
	job_id,
	department_id,
	RIGHT(last_name, 2) + cast(job_id as varchar(10)) + cast(department_id as varchar(10)) as windows_login_id
from employees


--or

select
	employee_id,
	email,
	job_id,
	department_id,
	concat(RIGHT(last_name, 2), job_id, department_id) as windows_login_id
from employees


select * from employees
-- Calculate Tenure (no of years spend in the company) of each emp
select
	employee_id,
	email,
	hire_date,
	DATEDIFF(year, hire_date, GETDATE()) as Tenure
from employees


---------------------------------------------------------
--------------  In and Like operators
---------------------------------------------------------

-- Show details for 4 employees
select * from employees
where employee_id in (206, 100, 101, 109)


-- Show details for employees whose first name starts with N
select * from employees
where first_name like 'n%'


-- show emp whose last name ends with R
select * from employees
where last_name like '%r'


-- show emp whose email contains EE anywhere
select * from employees
where email like '%ee%'


-- Subqueries

/*
A subquery is a query within another query. The outer query is called as main query and inner query is called as subquery. 
The subquery gets executes first. 
Subquery must be enclosed in parentheses.
A subquery can be placed in a number of SQL clauses like WHERE clause, FROM clause, HAVING clause.
In the Subquery, ORDER BY command cannot be used.
*/


-- Example - Show the details of employees with a dependent

-- Step 1: Investigate tables
select * from dependents

select * from employees


-- Step 2: Show employee details for a list of employees
select * from employees
where employee_id in (206, 100, 101, 109)


-- Step 3:
select * from employees
where employee_id in (select employee_id from dependents)


-----------------------------------------------------------------
-- Table Expressions
-----------------------------------------------------------------
/*
A table expression is a query that represents a valid relational table. 

T-SQL supports four types of table expressions: 
	derived tables
	common table expressions (CTEs)
	views
	Table-valued functions (TVFs)

These kind of queries must meet three requirements:
	1) Order is not guaranteed (No Order By)
	2) All columns must have names
	3) All column names must be unique

One of the benefits of using table expressions is that, you can refer to column aliases that were assigned 
in the SELECT clause of the inner query. This behaviour helps you get around the fact that you can�t refer to 
column aliases assigned in the SELECT clause in query clauses that are logically processed prior to the SELECT clause 
(for example, WHERE or GROUP BY).

*/


/* Derived Tables
Derived tables (also known as table subqueries) are defined in the FROM clause of an outer query.
Inner query defines the derived table within parentheses, followed by the AS clause and the derived table name.
*/


select 
	employee_id,
	email,
	salary,
	IIF(salary > 8000, 'High', 'Low') as SalCategory
from employees


-- Count how many employees are in High and Low SalCategory
select SalCategory, count(*) from
(select 
	employee_id,
	email,
	salary,
	IIF(salary > 8000, 'High', 'Low') as SalCategory
from employees) as x
group by SalCategory;



/*
Common table expressions (CTEs) are another standard form of table expression similar to derived tables.
CTEs are defined by using a WITH statement.
*/

with x as
(
	select 
		employee_id,
		email,
		salary,
		IIF(salary > 8000, 'High', 'Low') as SalCategory
	from employees
)
		
select SalCategory, count(*) 
from x
group by SalCategory


/*
On the surface, the difference between derived tables and CTEs might seem to be merely semantic. 
However, the fact that you first name and define a CTE and then use it gives it several important advantages over
derived tables. One advantage is that if you need to refer to one CTE from another, you don�t nest them; 
rather, you separate them by commas. Each CTE can refer to all previously defined CTEs, and the outer query 
can refer to all CTEs.

The fact that a CTE is named and defined first and then queried has another advantage: 
as far as the FROM clause of the outer query is concerned, the CTE already exists; therefore, 
you can refer to multiple instances of the same CTE in table operators like joins.

CTEs are unique among table expressions in the sense that they support recursion.
*/



/*
Derived tables and CTEs have a single-statement scope, which means they are not reusable. 
Views and table-valued functions (TVFs) are two types of table expressions whose definitions are stored as
permanent objects in the database, making them reusable.
*/


/* 
Views:

In SQL, a view is a virtual table based on the result-set of an SQL statement.

A view contains rows and columns, just like a real table. The fields in a view are fields from one or more real tables in the database.

You can add SQL statements and functions to a view and present the data as if the data were coming from one single table.

Views have the following benefits:
	> Security - Views can be made accessible to users while the underlying tables are not directly accessible. This allows the DBA to give users only the data they need, while protecting other data in the same table.
	> Simplicity - Views can be used to hide and reuse complex queries.
	> Column Name Simplification or Clarification - Views can be used to provide aliases on column names to make them more memorable and/or meaningful.
	> Stepping Stone - Views can provide a stepping stone in a "multi-level" query. 

A view is created with the CREATE VIEW statement. 
*/


-- Create a view which combines employee data from all the tables (except dependants)

create view v_FullEmpData as
(
	select 
		employees.*, job_title, min_salary, max_salary, department_name, street_address, postal_code,
		city, state_province, country_name, region_name
	from employees
	inner join jobs on employees.job_id = jobs.job_id
	inner join departments on employees.department_id = departments.department_id
	inner join locations on departments.location_id = locations.location_id
	inner join countries on locations.country_id = countries.country_id
	inner join regions on countries.region_id = regions.region_id
)


-- check
select * from v_FullEmpData


-- To delete a view
drop view if exists v_FullEmpData



