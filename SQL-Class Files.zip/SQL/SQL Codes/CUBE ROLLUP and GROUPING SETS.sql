
-- Create the Sales Table
Drop table if exists Sales
CREATE TABLE Sales (
    Order_ID INT PRIMARY KEY IDENTITY(1,1),
    Country VARCHAR(50) NOT NULL,
    State VARCHAR(50) NOT NULL,
    City VARCHAR(50) NOT NULL,
    Product_Category VARCHAR(50) NOT NULL,
    Product_Sub_Category VARCHAR(50) NOT NULL,
    Customer_Segment VARCHAR(50) NOT NULL,
    Sales DECIMAL(10, 2) NOT NULL,
    Profit DECIMAL(10, 2)
);

-- Insert 50 rows of data into the Sales table
INSERT INTO Sales (Country, State, City, Product_Category, Product_Sub_Category, Customer_Segment, Sales, Profit) VALUES
('India', 'Maharashtra', 'Mumbai', 'Electronics', 'Mobile', 'Corporate', 15000.00, 2000.00),
('India', 'Maharashtra', 'Pune', 'Stationary', 'Pen', 'Retail', 250.00, 50.00),
('India', 'Karnataka', 'Bangalore', 'Electronics', 'Laptop', 'Home Office', 65000.00, 8000.00),
('Australia', 'Western Australia', 'Perth', 'Electronics', 'TV', 'Corporate', 80000.00, 10000.00),
('Australia', 'Queensland', 'Brisbane', 'Stationary', 'Paper', 'Retail', 120.00, 25.00),
('India', 'Maharashtra', 'Mumbai', 'Electronics', 'Mobile', 'Retail', 12000.00, 1500.00),
('India', 'Maharashtra', 'Pune', 'Stationary', 'Pen', 'Corporate', 300.00, 60.00),
('India', 'Karnataka', 'Bangalore', 'Electronics', 'Laptop', 'Corporate', 70000.00, 9000.00),
('Australia', 'Western Australia', 'Perth', 'Electronics', 'TV', 'Home Office', 55000.00, 7000.00),
('Australia', 'Queensland', 'Brisbane', 'Stationary', 'Paper', 'Home Office', 150.00, 30.00),
('India', 'Maharashtra', 'Mumbai', 'Electronics', 'TV', 'Retail', 45000.00, 5500.00),
('India', 'Maharashtra', 'Pune', 'Stationary', 'Paper', 'Retail', 80.00, 15.00),
('India', 'Karnataka', 'Bangalore', 'Electronics', 'Mobile', 'Home Office', 18000.00, 2200.00),
('Australia', 'Western Australia', 'Perth', 'Stationary', 'Pen', 'Corporate', 200.00, 40.00),
('Australia', 'Queensland', 'Brisbane', 'Electronics', 'Laptop', 'Retail', 40000.00, 5000.00),
('India', 'Maharashtra', 'Mumbai', 'Electronics', 'Laptop', 'Retail', 58000.00, 7200.00),
('India', 'Maharashtra', 'Pune', 'Stationary', 'Paper', 'Corporate', 100.00, 20.00),
('India', 'Karnataka', 'Bangalore', 'Electronics', 'TV', 'Corporate', 90000.00, 11000.00),
('Australia', 'Western Australia', 'Perth', 'Stationary', 'Pen', 'Home Office', 220.00, 45.00),
('Australia', 'Queensland', 'Brisbane', 'Electronics', 'Mobile', 'Retail', 13000.00, 1600.00),
('India', 'Maharashtra', 'Mumbai', 'Stationary', 'Pen', 'Home Office', 180.00, 35.00),
('India', 'Maharashtra', 'Pune', 'Electronics', 'Mobile', 'Corporate', 16000.00, 2100.00),
('India', 'Karnataka', 'Bangalore', 'Stationary', 'Paper', 'Retail', 90.00, 18.00),
('Australia', 'Western Australia', 'Perth', 'Electronics', 'Laptop', 'Corporate', 75000.00, 9500.00),
('Australia', 'Queensland', 'Brisbane', 'Stationary', 'Pen', 'Retail', 280.00, 55.00),
('India', 'Maharashtra', 'Mumbai', 'Electronics', 'TV', 'Home Office', 50000.00, 6000.00),
('India', 'Maharashtra', 'Pune', 'Stationary', 'Paper', 'Home Office', 130.00, 28.00),
('India', 'Karnataka', 'Bangalore', 'Electronics', 'Mobile', 'Retail', 11000.00, 1300.00),
('Australia', 'Western Australia', 'Perth', 'Stationary', 'Paper', 'Corporate', 110.00, 22.00),
('Australia', 'Queensland', 'Brisbane', 'Electronics', 'TV', 'Retail', 42000.00, 5200.00),
('India', 'Maharashtra', 'Mumbai', 'Stationary', 'Pen', 'Retail', 220.00, 42.00),
('India', 'Maharashtra', 'Pune', 'Electronics', 'Laptop', 'Home Office', 68000.00, 8500.00),
('India', 'Karnataka', 'Bangalore', 'Stationary', 'Paper', 'Corporate', 140.00, 30.00),
('Australia', 'Western Australia', 'Perth', 'Electronics', 'Mobile', 'Corporate', 17000.00, 2300.00),
('Australia', 'Queensland', 'Brisbane', 'Stationary', 'Pen', 'Home Office', 190.00, 38.00),
('India', 'Maharashtra', 'Mumbai', 'Electronics', 'TV', 'Corporate', 85000.00, 10500.00),
('India', 'Maharashtra', 'Pune', 'Stationary', 'Paper', 'Retail', 70.00, 12.00),
('India', 'Karnataka', 'Bangalore', 'Electronics', 'Laptop', 'Retail', 48000.00, 6000.00),
('Australia', 'Western Australia', 'Perth', 'Stationary', 'Pen', 'Retail', 260.00, 52.00),
('Australia', 'Queensland', 'Brisbane', 'Electronics', 'Mobile', 'Home Office', 14000.00, 1700.00),
('India', 'Maharashtra', 'Mumbai', 'Stationary', 'Paper', 'Corporate', 95.00, 19.00),
('India', 'Maharashtra', 'Pune', 'Electronics', 'TV', 'Retail', 40000.00, 5000.00),
('India', 'Karnataka', 'Bangalore', 'Stationary', 'Pen', 'Home Office', 210.00, 41.00),
('Australia', 'Western Australia', 'Perth', 'Electronics', 'Laptop', 'Home Office', 60000.00, 7500.00),
('Australia', 'Queensland', 'Brisbane', 'Stationary', 'Paper', 'Retail', 160.00, 32.00),
('India', 'Maharashtra', 'Mumbai', 'Electronics', 'Mobile', 'Home Office', 19000.00, 2400.00),
('India', 'Maharashtra', 'Pune', 'Stationary', 'Pen', 'Corporate', 270.00, 53.00),
('India', 'Karnataka', 'Bangalore', 'Electronics', 'TV', 'Retail', 52000.00, 6500.00),
('Australia', 'Western Australia', 'Perth', 'Stationary', 'Paper', 'Home Office', 125.00, 26.00),
('Australia', 'Queensland', 'Brisbane', 'Electronics', 'Laptop', 'Corporate', 72000.00, 9200.00);


select * from Sales

-- Example of Cube
SELECT
    Country,
    Product_Category,
    SUM(Sales) AS TotalSales
FROM
    Sales
GROUP BY CUBE (Country, Product_Category)


-- Example of rollup
SELECT
    Country,
    State,
    SUM(Sales) AS TotalSales
FROM
    Sales
GROUP BY ROLLUP (Country, State)

-- Another example of ROLLUP
SELECT
    Product_Category,
    Product_Sub_Category,
    SUM(Sales) AS TotalSales
FROM
    Sales
GROUP BY ROLLUP (Product_Category, Product_Sub_Category)



-- Example of GROUPING SETS
SELECT
    City,
    Product_Category,
    Customer_Segment,
    SUM(Profit) AS TotalProfit
FROM
    Sales
GROUP BY GROUPING SETS (
    (City, Product_Category), 
    (Product_Category, Customer_Segment)
)