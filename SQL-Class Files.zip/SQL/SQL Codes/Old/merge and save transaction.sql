----------------------------------------------------
-------  Save Transaction 
----------------------------------------------------

use Demo1

select * from tbl_emp

begin transaction
	insert into tbl_emp values (101, 'Test1', 'High')
save transaction point1
	insert into tbl_emp values (102, 'Test2', 'Low')
save transaction point2
	insert into tbl_emp values (103, 'Test3', 'Low')
save transaction point3
	insert into tbl_emp values (104, 'Test4', 'Low')
save transaction point4
	insert into tbl_emp values (105, 'Test5', 'Low')
rollback transaction point1
commit

select * from tbl_emp

delete from tbl_emp where emp_id > 10



------------------------------------------------
---------   Merge Command
------------------------------------------------

/*

The MERGE statement runs insert, update, or delete operations on a target table from the results of a join with a source table. 


 Syntax:
MERGE <target_table> [AS TARGET]
USING <table_source> [AS SOURCE]
ON <search_condition>
[WHEN MATCHED 
   THEN <merge_matched> ]
[WHEN NOT MATCHED [BY TARGET]
   THEN <merge_not_matched> ]
[WHEN NOT MATCHED BY SOURCE
   THEN <merge_matched> ]; 


> Every MERGE statement must end with a semi-colon. If a semi-colon is not present at the end of the MERGE statement, then an error will be thrown 
> It is mandatory that one of the MATCHED clauses is provided in order for the MERGE statement to operate 

*/


create table prod_source (
	id int,
	name varchar(20),
	price int
)

create table prod_target (
	id int,
	name varchar(20),
	price int
)

delete from prod_source

insert into prod_source
values
(1, 'Pen', 30),
(3, 'Ref Book', 100),
(4, 'Calculator', 500)


delete from prod_target

insert into prod_target
values
(1, 'Pen', 20),
(2, 'Pencil', 10),
(3, 'Book', 115)

select * from prod_source
select * from prod_target

merge prod_target as t
using prod_source as s
on t.id = s.id
when matched then 
	update set t.name = s.name, t.price = s.price
when not matched by target then
	insert (id, name, price) values (s.id, s.name, s.price)
when not matched by source then
	delete;


	