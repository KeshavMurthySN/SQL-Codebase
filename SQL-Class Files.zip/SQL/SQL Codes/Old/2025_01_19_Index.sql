-------------------------------------------
-- Index
-------------------------------------------

/*
An index is a database object. It is used by the server to speed up the retrieval of rows.
An index helps to speed up select queries and where clauses, but it slows down data input like the update, delete and the insert statements. Indexes can be created or dropped with no effect on the data. 

-----------------------------------------

Syntax:
	CREATE INDEX index
	ON TABLE column;

and
	DROP INDEX index;

and 
	ALTER INDEX IndexName
	ON TableName;

----------------------------------------

In general, it�s a good practice to only create indexes on columns that are frequently used in queries and to avoid creating indexes on columns that are rarely used. It�s also a good idea to periodically review the indexes in your database and remove any that are no longer needed.

*/


use HR_2

-- Lets look at employee table
select * from employees

-- Lets say we are using the Salary column quite frequently in where clause
-- Lets create an index on salary columns to enhance the performance of our queries

create index ix_employee_salary
on employees (salary)


-- To list the indexes in a table, use the following stored procedure
sp_helpindex employees

-- To drop an index
drop index employees.ix_employee_salary

-- We can also use the Designer/GUI to do these things




/*
Different kinds of indexes in SQL Server:
https://learn.microsoft.com/en-us/sql/relational-databases/indexes/indexes?view=sql-server-ver16


A clustered index is an index which defines the physical order in which table records are stored in a database. Since there can be only one way in which records are physically stored in a database table, there can be only one clustered index per table. By default a clustered index is created on a primary key column.

*/

-- Lets create a new table

CREATE TABLE tmp_employees
(
emp_id INT NOT NULL,
name VARCHAR(50) NOT NULL,
gender VARCHAR(50) NOT NULL,
age INT NOT NULL
)

-- Lets insert some values into the table
INSERT INTO tmp_employees
VALUES
(4, 'Ana', 'Female', 40),
(2, 'Jon', 'Male', 20),
(3, 'Mike', 'Male', 54),
(1, 'Sara', 'Female', 34),
(5, 'Nick', 'Female', 29)


-- Lets look at the records
select * from tmp_employees


-- Lets also check the current indexes in the table
sp_helpindex tmp_employees


-- Lets make emp_id a primary key
ALTER TABLE tmp_employees
ADD CONSTRAINT pk_tmp_emp_id PRIMARY KEY (emp_id)


-- Now look at the table again. Notice the sorting
select * from tmp_employees


-- Lets also check the current indexes in the table
sp_helpindex tmp_employees



------------------------------------

/*
Non-Clustered Indexes
A non-clustered index is also used to speed up search operations. Unlike a clustered index, a non-clustered index doesn�t physically define the order in which records are inserted into a table. In fact, a non-clustered index is stored in a separate location from the data table and hence there can be multiple non-clustered indexes per table.

To create a non-clustered index, you have to use the �CREATE NONCLUSTERED� statement. The rest of the syntax remains the same as the syntax for creating a clustered index. 
*/


-- Example
CREATE NONCLUSTERED INDEX ix_tmp_employees_Name
ON tmp_employees(name)


sp_helpindex tmp_employees


-- We can create as many non clustered index as required
CREATE NONCLUSTERED INDEX ix_tmp_employees_Age
ON tmp_employees(age)


-- We can also create an index with multiple columns
CREATE NONCLUSTERED INDEX ix_tmp_employees_NameAgeGender
ON tmp_employees(Name)
INCLUDE (gender,age)

---------------------------------------

-- Solution of Edureka Module 6 assignment

use Students

SET STATISTICS IO ON
SET STATISTICS TIME ON

select count(*) from CourseEnrollments

select COUNT(*) from CourseOfferings


select * from
CourseOfferings
left join CourseEnrollments
on CourseOfferings.CourseOfferingId = CourseEnrollments.CourseOfferingId
where TermCode = 'SP2016'



CREATE NONCLUSTERED INDEX ix_test
ON [dbo].[CourseEnrollments] ([CourseOfferingId])
INCLUDE ([StudentId],[Grade])



drop index CourseEnrollments.ix_test



SET STATISTICS IO OFF
SET STATISTICS TIME OFF
