
---------------------------------------------------------------
--------------------- Topics for today ------------------------
---------------------------------------------------------------

/*
	Connecting to a cloud server 
	Distinct/Unique Values
	Union query
	Except / Intersect
	Calculating new columns
	Built In Functions
		String functions - left, right, len, etc.
		Date functions - getdate, datediff, etc.
		Type Conversion - cast
*/


/*
	Server Name: 3.143.125.139
	Authentication: SQL Server Authentication
	Login: SQL
	Password: SQL
*/


-- Put the correct DB in use
use SuperstoreUS;


-- Preview the table
select * from orders_central 


-- Fetch unique state names
select distinct(state) from orders_central


-- Question: Fetch distinct cities in the state of Texas


-- Preview a table
select * FROM Orders_East;


-- Append data from multiple tables
select * from Orders_East
union
select * from Orders_West
union 
select * from Orders_central;


-- Find exclusive records which are present only in first table
select [Customer Name] from orders_central
except
select [Customer Name] from orders_east


-- Other way round
select [Customer Name] from orders_east
except
select [Customer Name] from orders_central


-- Find customers common in both tables
select [Customer Name] from orders_east
intersect
select [Customer Name] from orders_central


------------------------------------------------
------- Calculating New Columns ----------------
------------------------------------------------


-- Calculate cost

-- Step 1:
select top(10) [Row ID], [Product Name], [Customer Name], Sales, Profit
from Orders_Central;

-- Step 2:
select top(10)	[Row ID], 
				[Product Name], 
				[Customer Name], 
				Sales, 
				Profit,
				Sales - Profit as Cost  -- this is a new calculated column
from Orders_Central;




-- create customer user id by concatenating the first two characters and the last three characters of their customer ID

-- step 1:
select 
	distinct([Customer ID])
from Orders_Central


-- step 2:
select 
	distinct([Customer ID]),
	left([Customer ID],2) + RIGHT([Customer ID],3) as 'customer user id'
from Orders_Central




-- Find the customer with the shortest name
select 
	distinct([Customer Name]),
	len([Customer Name]) as NameLength
from Orders_Central
order by NameLength asc;




-- Calculate turn around time
-- Find the row with highest TAT
select 
	[Row ID],
	[Order Date],
	[Ship Date],
	datediff(day, [Order Date],[Ship Date]) as TAT
from Orders_Central
order by TAT desc;



-- Age calculation
-- Lets assume that Order date is date of birth
select 
	[Row ID],
	[Order Date],
	datediff(year, [Order Date], getdate()) as Age
from orders_central;




-- Type conversion
-- Calculate Profit Ratio
select
	[Row ID],
	Sales,
	Profit,
	Profit/Sales as ProfitMargin
from Orders_Central;

-- Show profit ratio with only 2 decimal places
select
	[Row ID],
	Sales,
	Profit,
	cast(Profit/Sales as decimal(8,2)) as ProfitMargin
from Orders_Central;




-- Show discount in percentage format
-- Step 1:
select 
	[Row ID],
	Discount,
	Discount*100 + '%' as disc
from Orders_Central;


-- Step 2:
select 
	[Row ID],
	Discount,
	cast(Discount*100 as varchar) + '%' as disc
from Orders_Central;


-- Alternate method
select 
	[Row ID],
	Discount,
	concat(Discount*100 , '%') as disc
from Orders_Central;