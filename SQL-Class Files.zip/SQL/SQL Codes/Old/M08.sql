	
-- Set the database in use
Use HR_Edureka


------------------------------------------------------------------
-- Stored Procedures
------------------------------------------------------------------

/* A stored procedure is a group of SQL statements that are created and stored in a database management system, 
allowing multiple users and programs to share and reuse the procedure. A stored procedure can accept 
input parameters, perform the defined operations, and return multiple output values. */

/* Syntax:
CREATE PROCEDURE procedure_name     (we can also use PROC)
AS 
BEGIN 
sql_statement 
END 
*/

/* Best Practices:
> Use SET NOCOUNT ON
> Use a consistent nomenclature like spABC (but not sp_ABC)
*/


-- create a simple stored procedure
create procedure spDemo1
as
begin
	select * from v_FullHRData where department_name = 'Sales'
end


-- Execute the stored procedure
spDemo1

-- or
exec spDemo1

-- or
execute spDemo1


/* When each statement is executed in a stored procedure, the SQL Server returns the number of rows 
that are affected as part of the results. To reduce network traffic and improve performance, 
use SET NOCOUNT ON at the beginning of the stored procedure.*/
create proc spDemo2
as
begin
	set nocount on
	select * from v_FullHRData where department_name = 'Sales'
end


-- Execute and look at the message window
exec spDemo2


-- There are some system stored procedures as well. We use sp_helptext to view our code
sp_helptext spDemo1

sp_helptext spDemo2


-- Below web page explains some other useful system stored procedures
-- https://www.sudshekhar.com/blog/useful-system-stored-procedure-in-sql


-- To modify a stored procedure use the alter command
alter proc spDemo2
as
begin
	set nocount on
	select * from v_FullHRData where department_name = 'IT'
end


-- To delete a stored procedure use the DROP command
drop proc spDemo2

-- or, just to play it safe
drop proc if exists spDemo2


-- we can encrypt a stored procedure
alter procedure spDemo1
with encryption    -- check out this new line
as
begin
	select * from v_FullHRData where department_name = 'Sales'
end

-- we can not see the logic inside the procedure now
sp_helptext spDemo1


-- Stored Procedures can accept input parameters
create proc spDemo3
	@DepName as varchar(50)
as
begin
	select * from v_FullHRData where department_name = @DepName
end


-- Execute the proc to get data for IT department
exec spDemo3 @DepName = 'IT'


-- Execute the proc to get data for Sales department
exec spDemo3 'Sales'


-- Stored Procedures can accept multiple input parameters
create proc spDemo4 
	@DepName as varchar(50), 
	@SalCutOff as int
as
begin
	select * from v_FullHRData where department_name = @DepName and salary > @SalCutOff
end

-- Implicit passing of parameter values. Order is important
exec spDemo4 'Sales', 7500

-- Explicit passing of parameter values
exec spDemo4 @SalCutOff = 5000, @DepName = 'IT'


-- Use the sp_help system stored procedure to get an idea about the parametrs required
sp_help spDemo4


-- Not passing a parameter value will lead to an error
exec spDemo4 @DepName = 'IT'


-- We can make an argument optional by setting a default value for it
-- If no value for the parameter is supplied then the default value will be used
alter proc spDemo4
	@DepName as varchar(50), 
	@SalCutOff as int = 0
as
begin
	select * from v_FullHRData where department_name = @DepName and salary > @SalCutOff
end


-- Now we can call the use the SP without Salary Cutoff value
exec spDemo4 @DepName = 'IT'

-- We can supply it if we want to
exec spDemo4 @DepName = 'IT', @SalCutOff = 5000


-- We can make both arguments optional
alter proc spDemo4
	@DepName as varchar(50) = 'x', 
	@SalCutOff as int = 0
as
begin
	if @DepName = 'x'
		select * from v_FullHRData where salary > @SalCutOff
	else
		select * from v_FullHRData where department_name = @DepName and salary > @SalCutOff
end


-- We can now execute the stored procedure in different ways
exec spDemo4

exec spDemo4 @SalCutOff = 9000

exec spDemo4 @DepName = 'Sales'

exec spDemo4 @DepName = 'Sales', @SalCutOff = 9000


-- another useful system stored procedure
sp_depends spDemo4

sp_depends v_FullHrData


--------------------------------------
-- User Defined Function
--------------------------------------

/*
Like functions in programming languages, SQL Server user-defined functions are routines 
that accept parameters, perform an action, such as a complex calculation, and return the 
result of that action as a value. The return value can either be a single scalar value or a result set.


UDF are of two types:
1) Scalar functions - return a single data value
2) Table-valued functions - return a table


Scalar UDF syntax:

CREATE FUNCTION [database_name.]function_name (parameters)
RETURNS data_type AS
BEGIN
    SQL statements
    RETURN value
END;
    
ALTER FUNCTION [database_name.]function_name (parameters)
RETURNS data_type AS
BEGIN
    SQL statements
    RETURN value
END;
    
DROP FUNCTION [database_name.]function_name;

For Table-valued functions the BEGIN - END statements are not needed
*/

-- Scalar functions may or may not have parameters, but will always return a single (scalar) value
-- The returned value can be of any data type except text, ntext, image, cursor and timestamp

create function f_bonus(@Sal as float)
returns float
as
begin
	declare @bns float
	set @bns = @Sal * 0.1
	return @bns
end


-- While using the function please ensure to use the two part name
select employee_id, salary, dbo.f_bonus(salary) as BonusAmount
from v_FullHrData


-- We cannot use a stored procedure in a select or where clause
-- but we can use functions
select employee_id, salary, dbo.f_bonus(salary) as BonusAmount
from v_FullHrData
where dbo.f_bonus(salary) > 1000


-- if you want to see the logic inside the function then use the system stored procedure
sp_helptext f_bonus


-- Like stored procedures, we can encrypt the function as well
alter function f_bonus (@Sal as float)
returns float
with encryption
as
begin
	declare @bns float
	set @bns = @Sal * 0.1
	return @bns
end


-- after encryption try the sp_helptext again
sp_helptext f_bonus


-- Another example
create function f_Compa(@Sal as float, @MinSal as float, @MaxSal as float)
returns float
as
begin
	declare @MedianSal float
	set @MedianSal = (@MinSal + @MaxSal)/2
	declare @CompaRatio float
	set @CompaRatio = @Sal / @MedianSal
	return @CompaRatio
end

-- Lets use the function
select 
	employee_id, 
	email, 
	salary, 
	min_salary, 
	max_salary, 
	dbo.f_compa(salary, min_salary, max_salary) as 'Compa Ratio'
from v_FullHrData


-- ANother example on date values
create function f_BonusDate (@hire_dt as date)
returns date
as
begin
	declare @bonus_dt as date
	declare @year as int
	set @year = year(getdate())
	set @bonus_dt = DATEFROMPARTS(@year, month(@hire_dt),day(@hire_dt))
	return @bonus_dt
end


-- use the function
select employee_id, hire_date, dbo.f_BonusDate(hire_date) as DateOfBonusPay
from v_FullHrData


