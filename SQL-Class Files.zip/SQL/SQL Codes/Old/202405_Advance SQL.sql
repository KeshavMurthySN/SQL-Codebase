
--------------------------------------------
/*
Topics:
	Windows Functions
	Derived Tables
	CTE
	Stored Procedures
*/
--------------------------------------------

/*
Introduction:
A window function performs a calculation across a set of table rows that are somehow related to the current row. 
This is comparable to the type of calculation that can be done with an aggregate function. 
But unlike regular aggregate functions, use of a window function does not cause rows to become 
grouped into a single output row � the rows retain their separate identities.

The key to windowing functions is in controlling the order in which the rows are evaluated

Windows functions are performed using the OVER clause.

There are three groups of functions that the OVER clause can be applied to:
	1) aggregate functions (sum, avg, max, min, etc.)
	2) ranking functions (row_number, rank, dense_rank, etc.)
	3) analytic functions (first_value, last_value, lag, lead, etc.)

*/

---------------------------------------------


use HR


-- lets look at employee id, email, salary and dept name

select employee_id, email, department_name, salary
from v_FullEmpData


-- recap of aggregate queries

select max(salary) from v_FullEmpData


select department_name, max(Salary)
from v_FullEmpData
group by department_name

-- Please note that in above queries we are losing row level details

-- If we use windows functions then we will be able to see both row level and aggregate level data together

-- Compare the salary of each employee against the salary of the highest paid person in the company

select	employee_id, email, department_name, salary,
		max(salary) over() as 'Highest_Company_Sal'
from v_FullEmpData


-- Compare the salary of each employee against the salary of the highest paid person in their respective department

select	employee_id, email, department_name, salary,
		max(salary) over(partition by department_name) as 'Highest_Dept_Sal'
from v_FullEmpData


-- Show top paid employee of each department

-- Step 1: 

select	employee_id, email, department_name, salary,
		ROW_NUMBER() over(order by salary desc) as 'rn' 
from v_FullEmpData

-- Step 2:

select	employee_id, email, department_name, salary,
		ROW_NUMBER() over(partition by department_name order by salary desc) as 'rn' 
from v_FullEmpData

-- Step 3:

select * from
(
	select	employee_id, email, department_name, salary,
			ROW_NUMBER() over(partition by department_name order by salary desc) as 'rn' 
	from v_FullEmpData) as x
where rn = 1


-- Compare row_number, rank and dense_rank

select	employee_id, email, department_name, salary,
		ROW_NUMBER() over(order by salary desc) as 'rn',
		rank() over(order by salary desc) as 'rnk',
		dense_rank() over(order by salary desc) as 'drnk'
from v_FullEmpData


-- Increase in Salary budget over time

-- Inspect the data

select employee_id, email, hire_date, salary
from v_FullEmpData
order by hire_date

-- Increase in Salary Expense over time for the whole company

select	employee_id, email, hire_date, salary,
		sum(salary) over(order by hire_date) as 'Cumulative_SalExpense'
from v_FullEmpData


-- Increase in Salary Expense over time for each department

select	employee_id, email, hire_date, department_name, salary,
		sum(salary) over(partition by department_name order by hire_date) as 'Cumulative_SalExpense'
from v_FullEmpData



-----------------------------------------------------------------
-- Table Expressions
-----------------------------------------------------------------
/*
A table expression is a query that represents a valid relational table. 

T-SQL supports four types of table expressions: 
	derived tables
	common table expressions (CTEs)
	views
	Table-valued functions (TVFs)

These kind of queries must meet three requirements:
	1) Order is not guaranteed (No Order By)
	2) All columns must have names
	3) All column names must be unique

One of the benefits of using table expressions is that, you can refer to column aliases that were assigned 
in the SELECT clause of the inner query. This behavior helps you get around the fact that you can�t refer to 
column aliases assigned in the SELECT clause in query clauses that are logically processed prior to the SELECT clause 
(for example, WHERE or GROUP BY).

*/


/* Derived Tables
Derived tables (also known as table subqueries) are defined in the FROM clause of an outer query.
Inner query defines the derived table within parentheses, followed by the AS clause and the derived table name.
*/

-- We have already seen a derived table in our previous example

select * from
(
	select	employee_id, email, department_name, salary,
			ROW_NUMBER() over(partition by department_name order by salary desc) as 'rn' 
	from v_FullEmpData) as x
where rn = 1



/*
Common table expressions (CTEs) are another standard form of table expression similar to derived tables.
CTEs are defined by using a WITH statement.
*/

with x as (
	select	employee_id, email, department_name, salary,
			ROW_NUMBER() over(partition by department_name order by salary desc) as 'rn' 
	from v_FullEmpData)

select * from x where rn = 1

/*
On the surface, the difference between derived tables and CTEs might seem to be merely semantic. 
However, the fact that you first name and define a CTE and then use it gives it several important advantages over
derived tables. One advantage is that if you need to refer to one CTE from another, you don�t nest them; 
rather, you separate them by commas. Each CTE can refer to all previously defined CTEs, and the outer query 
can refer to all CTEs.

The fact that a CTE is named and defined first and then queried has another advantage: 
as far as the FROM clause of the outer query is concerned, the CTE already exists; therefore, 
you can refer to multiple instances of the same CTE in table operators like joins.

CTEs are unique among table expressions in the sense that they support recursion.
*/



/*
Derived tables and CTEs have a single-statement scope, which means they are not reusable. 
Views and table-valued functions (TVFs) are two types of table expressions whose definitions are stored as
permanent objects in the database, making them reusable.
*/




------------------------------------------------------------------
-- Stored Procedures
------------------------------------------------------------------

/* A stored procedure is a group of SQL statements that are created and stored in a database management system, 
allowing multiple users and programs to share and reuse the procedure. A stored procedure can accept 
input parameters, perform the defined operations, and return multiple output values. */

/* Syntax:
CREATE PROCEDURE procedure_name     (we can also use PROC)
AS 
BEGIN 
sql_statement 
END 
*/

/* Best Practices:
> Use SET NOCOUNT ON
> Use a consistent nomenclature like spABC (but not sp_ABC)
*/


-- create a simple stored procedure
create procedure spDemo1
as
begin
	select * from v_FullEmpData where department_name = 'Sales'
end


-- Execute the stored procedure
spDemo1

-- or
exec spDemo1

-- or
execute spDemo1


/* When each statement is executed in a stored procedure, the SQL Server returns the number of rows 
that are affected as part of the results. To reduce network traffic and improve performance, 
use SET NOCOUNT ON at the beginning of the stored procedure.*/
create proc spDemo2
as
begin
	set nocount on
	select * from v_FullEmpData where department_name = 'Sales'
end


-- Execute and look at the message window
exec spDemo2


-- There are some system stored procedures as well. We use sp_helptext to view our code
sp_helptext spDemo1

sp_helptext spDemo2


-- Below web page explains some other useful system stored procedures
-- https://www.sudshekhar.com/blog/useful-system-stored-procedure-in-sql


-- To modify a stored procedure use the alter command
alter proc spDemo2
as
begin
	set nocount on
	select * from v_FullEmpData where department_name = 'IT'
end


-- To delete a stored procedure use the DROP command
drop proc spDemo2

-- or, just to play it safe
drop proc if exists spDemo2


-- we can encrypt a stored procedure
alter procedure spDemo1
with encryption    -- check out this new line
as
begin
	select * from v_FullEmpData where department_name = 'Sales'
end

-- we can not see the logic inside the procedure now
sp_helptext spDemo1


-- Stored Procedures can accept input parameters
create proc spDemo3
	@DepName as varchar(50)
as
begin
	select * from v_FullEmpData where department_name = @DepName
end


-- Execute the proc to get data for IT department
exec spDemo3 @DepName = 'IT'


-- Execute the proc to get data for Sales department
exec spDemo3 'Sales'


-- Stored Procedures can accept multiple input parameters
create proc spDemo4 
	@DepName as varchar(50), 
	@SalCutOff as int
as
begin
	select * from v_FullEmpData where department_name = @DepName and salary > @SalCutOff
end

-- Implicit passing of parameter values. Order is important
exec spDemo4 'Sales', 7500

-- Explicit passing of parameter values
exec spDemo4 @SalCutOff = 5000, @DepName = 'IT'

