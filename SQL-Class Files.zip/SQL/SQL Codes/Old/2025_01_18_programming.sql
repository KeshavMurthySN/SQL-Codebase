---------------------------------------------------------------
--------------------- Topics for today ------------------------
---------------------------------------------------------------

/*
	Windows Function
	Stored Procedures
	User Defined Functions (UDF):
		Scalar Functions
		Table Valued Functions (TVF)
	Triggers
*/



use HR_2



----------------------------------------------------
----Windows Function:
----------------------------------------------------

/*
A window function performs a calculation across a set of table rows that are somehow related to the current row. 
This is comparable to the type of calculation that can be done with an aggregate function. 
But unlike regular aggregate functions, use of a window function does not cause rows to become 
grouped into a single output row � the rows retain their separate identities.

The key to windowing functions is in controlling the order in which the rows are evaluated

Windows functions are performed using the OVER clause.

There are three groups of functions that the OVER clause can be applied to:
	1) aggregate functions (sum, avg, max, min, etc.)
	2) ranking functions (row_number, rank, dense_rank, etc.)
	3) analytic functions (first_value, last_value, lag, lead, etc.)

*/

---------------------------------------------



-- lets look at employee id, email, salary and dept name

select employee_id, email, department_name, salary
from v_FullEmpData


-- recap of aggregate queries

select max(salary) from v_FullEmpData


select department_name, max(Salary)
from v_FullEmpData
group by department_name

-- Please note that in above queries we are losing row level details

-- If we use windows functions then we will be able to see both row level and aggregate level data together

-- Compare the salary of each employee against the salary of the highest paid person in the company

select	employee_id, email, department_name, salary,
		max(salary) over() as 'Highest_Company_Sal'
from v_FullEmpData


-- Compare the salary of each employee against the salary of the highest paid person in their respective department

select	employee_id, email, department_name, salary,
		max(salary) over(partition by department_name) as 'Highest_Dept_Sal'
from v_FullEmpData


-- Show top paid employee of each department

-- Step 1: 

select	employee_id, email, department_name, salary,
		ROW_NUMBER() over(order by salary desc) as 'rn' 
from v_FullEmpData

-- Step 2:

select	employee_id, email, department_name, salary,
		ROW_NUMBER() over(partition by department_name order by salary desc) as 'rn' 
from v_FullEmpData

-- Step 3:

select * from
(
	select	employee_id, email, department_name, salary,
			ROW_NUMBER() over(partition by department_name order by salary desc) as 'rn' 
	from v_FullEmpData) as x
where rn = 1


-- Compare row_number, rank and dense_rank

select	employee_id, email, department_name, salary,
		ROW_NUMBER() over(order by salary desc) as 'rn',
		rank() over(order by salary desc) as 'rnk',
		dense_rank() over(order by salary desc) as 'drnk'
from v_FullEmpData


-- Increase in Salary budget over time

-- Inspect the data

select employee_id, email, hire_date, salary
from v_FullEmpData
order by hire_date

-- Increase in Salary Expense over time for the whole company

select	employee_id, email, hire_date, salary,
		sum(salary) over(order by hire_date) as 'Cumulative_SalExpense'
from v_FullEmpData


-- Increase in Salary Expense over time for each department

select	employee_id, email, hire_date, department_name, salary,
		sum(salary) over(partition by department_name order by hire_date) as 'Cumulative_SalExpense'
from v_FullEmpData



------------------------------------------------------------------
-- Stored Procedures
------------------------------------------------------------------

/* A stored procedure is a group of SQL statements that are created and stored in a database management system, 
allowing multiple users and programs to share and reuse the procedure. A stored procedure can accept 
input parameters, perform the defined operations, and return multiple output values.

Syntax:
CREATE PROCEDURE procedure_name     (we can also use PROC)
AS 
BEGIN 
sql_statement 
END 
*/




-- create a simple stored procedure
create procedure spDemo1
as
begin
	select * from v_FullEmpData where department_name = 'Sales'
end


-- Execute the stored procedure
spDemo1

-- or
exec spDemo1

-- or
execute spDemo1



-- There are some system stored procedures as well. We use sp_helptext to view our code
sp_helptext spDemo1



-- Below web page explains some other useful system stored procedures
-- https://www.sudshekhar.com/blog/useful-system-stored-procedure-in-sql



-- we can encrypt a stored procedure
alter procedure spDemo1
with encryption    -- check out this new line
as
begin
	select * from v_FullEmpData where department_name = 'Sales'
end


-- we can not see the logic inside the procedure now
sp_helptext spDemo1



-- To delete a stored procedure use the DROP command
drop proc if exists spDemo1



-- Stored Procedures can accept input parameters
create proc spDemo3
	@DepName as varchar(50)
as
begin
	select * from v_FullEmpData where department_name = @DepName
end


-- Execute the proc to get data for IT department
exec spDemo3 @DepName = 'IT'


-- Execute the proc to get data for Sales department
exec spDemo3 'Sales'


-- Stored Procedures can accept multiple input parameters
create proc spDemo4 
	@DepName as varchar(50), 
	@SalCutOff as int
as
begin
	select * from v_FullEmpData where department_name = @DepName and salary > @SalCutOff
end


-- Implicit passing of parameter values. Order is important
exec spDemo4 'Sales', 7500

-- Explicit passing of parameter values
exec spDemo4 @SalCutOff = 5000, @DepName = 'IT'




--------------------------------------
-- User Defined Function
--------------------------------------

/*
Like functions in programming languages, SQL Server user-defined functions are routines 
that accept parameters, perform an action, such as a complex calculation, and return the 
result of that action as a value. The return value can either be a single scalar value or a result set.


UDF are of two types:
1) Scalar functions - return a single data value
2) Table-valued functions - return a table


Scalar UDF syntax:

CREATE FUNCTION [database_name.]function_name (parameters)
RETURNS data_type AS
BEGIN
    SQL statements
    RETURN value
END;
    
ALTER FUNCTION [database_name.]function_name (parameters)
RETURNS data_type AS
BEGIN
    SQL statements
    RETURN value
END;
    
DROP FUNCTION [database_name.]function_name;

For Table-valued functions the BEGIN - END statements are not needed
*/

-- Scalar functions will always return a single (scalar) value

create function f_bonus(@Sal as float)
returns float
as
begin
	declare @bns float
	set @bns = @Sal * 0.1
	return @bns
end


-- While using the function please ensure to use the two part name
select employee_id, salary, dbo.f_bonus(salary) as BonusAmount
from v_FullEmpData


-- We cannot use a stored procedure in a select or where clause
-- but we can use functions
select employee_id, salary, dbo.f_bonus(salary) as BonusAmount
from v_FullEmpData
where dbo.f_bonus(salary) > 1000


-- if you want to see the logic inside the function then use the system stored procedure
sp_helptext f_bonus


-- Like stored procedures, we can encrypt the function as well
alter function f_bonus (@Sal as float)
returns float
with encryption
as
begin
	declare @bns float
	set @bns = @Sal * 0.1
	return @bns
end


-- after encryption try the sp_helptext again
sp_helptext f_bonus


-- Another example
create function f_Compa(@Sal as float, @MinSal as float, @MaxSal as float)
returns float
as
begin
	declare @MedianSal float
	set @MedianSal = (@MinSal + @MaxSal)/2
	declare @CompaRatio float
	set @CompaRatio = @Sal / @MedianSal
	return @CompaRatio
end


-- Lets use the function
select 
	employee_id, 
	email, 
	salary, 
	min_salary, 
	max_salary, 
	dbo.f_compa(salary, min_salary, max_salary) as 'Compa Ratio'
from v_FullEmpData


-- ANother example on date values
create function f_BonusDate (@hire_dt as date)
returns date
as
begin
	declare @bonus_dt as date
	declare @year as int
	set @year = year(getdate())
	set @bonus_dt = DATEFROMPARTS(@year, month(@hire_dt),day(@hire_dt))
	return @bonus_dt
end


-- use the function
select employee_id, hire_date, dbo.f_BonusDate(hire_date) as DateOfBonusPay
from v_FullEmpData



---------------------------------------
/*

A Table-Valued Function (TVF) is a user defined function in SQL that returns a table as output. It can also take input parameters.

You can use a TVF in the FROM clause of a SELECT statement, just like a regular table.

Now, you might wonder�what is the difference between a TVF and a View?

Both Views as well as TVF are like a virtual table that fetches data from one or more real tables. However, the key difference is that Views cannot accept parameters, while TVFs can.

*/

-------------------------------------

-- Demo: Create a new Table Valued Function
-- please note that it will always return a Table and there is no BEGIN - END statement
create function f_t_getEmpDetails(@empid as int)
returns table
as
return 
(
	select employee_id, first_name, last_name, department_id, email from employees 
	where employee_id = @empid
)

-- use the function to fetch the records for employee number 101
select * from f_t_getEmpDetails(101)


-- Alter the function. We already restricted columns, now lets restrict rows as well
alter function f_t_getEmpDetails(@empid as int)
returns table
as
return 
(
	select employee_id, first_name, last_name, department_id, email from employees 
	where department_id <> 6
	and employee_id = @empid
)

-- Use the TVF to fetch the required data.
-- Employee ID 105 works in department number 6 
select * from f_t_getEmpDetails(105)

-- Employee ID 101 works in department number 9
select * from f_t_getEmpDetails(101)


-- To see the details about a function (like required parameters, etc) use the following stored procedure
sp_help f_t_getEmpDetails



---------------------------------------------------------

/*

What is a trigger?

A trigger is a stored procedure in a database that automatically invokes whenever an event in the database occurs. 

What kind of events?
	1) Data Definition Language (DDL) events such as Create table, Create view, drop table, Drop view, and Alter table, etc.
	2) Data Manipulation Language (DML) events that begin with Insert, Update, and Delete.
	3) LOGON event. When a user session is created with a SQL Server instance after the authentication process of logging is finished but before establishing a user session, the LOGON event takes place.

Because a trigger cannot be called directly, unlike a stored procedure, it is referred to as a special procedure. A trigger is automatically called whenever a data modification event against a table takes place, which is the main distinction between a trigger and a procedure. Since a trigger cannot be called directly hence we cannot pass a parameter to it. 

Some of the benefits of using SQL triggers:
	> Data integrity: Triggers allow you to enforce complex business rules and constraints at the database level, ensuring that data remains consistent and accurate.
	> Automation: Triggers can automate repetitive or complex tasks by executing predefined actions whenever a specified event occurs. This reduces the need for manual intervention and improves efficiency.
	> Audit trails: Triggers can be used to track changes made to data, such as logging modifications in a separate audit table. This helps in auditing and maintaining a history of data changes.

*/


-----------------------------------------------------
-----  DDL Trigger
-----------------------------------------------------

-- Lets create a trigger which prevents deleting or creating tables in the database

-- before that lets try creating a table
create table temp
(ID int, Gender varchar(10), Age int)

-- Lets try deleting the table
drop table temp


-- Now lets create our trigger and then try creating the table again
create trigger tr_trigger1
on database    -- we can set it to on all server as well
for create_table -- we can also use alter_table, drop_table, etc.
as
begin
	rollback
	print 'Sorry. Hard Luck. Thats not allowed. My trigger will block you'
end


-- Now disable the trigger and try again
disable trigger tr_trigger1 on database


-- Now enable the trigger and try again
enable trigger tr_trigger1 on database


-- To delete the trigger permanently
drop trigger tr_trigger1 on database


---------------------------------------------------------
----   DML Trigger
---------------------------------------------------------

/*
	DML trigger statements use two special tables: the deleted table and the inserted table. You can use these temporary, memory-resident tables to test certain data modifications' effects and set conditions for DML trigger actions. SQL Server automatically creates and manages these tables.

For multiple DML operations being done in the trigger, these tables are affected in the following manner.

    If any record is being inserted into the main table, a new entry of the document being created is also inserted into the INSERTED table.  
    If any record is being deleted from the main table, an entry of the record is being deleted is inserted into the DELETED table.  
    If any record is being updated in the main table, an entry of that record (before it was updated) is added to the DELETED table, and another entry of that record (after it was updated) is inserted into the INSERTED table.
*/


-- To test the inserted and deleted tables lets create a new temporary table
drop table if exists temp
create table temp
(ID int, Gender varchar(10), Age int)


-- Now lets create a trigger through which we will be able to select the inserted and deleted tables
-- Please remember that you can access these two tables only through a trigger, not directly  
create or alter trigger tr_trigger
on temp
for insert, update, delete
as
begin
	select * from inserted
	select * from deleted
end


-- Lets execute the trigger by inserting some record
insert into temp
values
(123,'M',34),
(222, 'F', 64)


-- Lets delete that record
delete from temp
where id = 222


select * from temp


update temp set Gender = 'F', age = 19
where id = 123



/*
Problem Statement:

Create 3 tables 
	> t_active_emp_details to hold details of all employees currently employed
	> t_terminated_emp_list to hold a list of employee ids which have been terminated
	> t_past_emp_details to hold details of past employees

As soon as we enter an employee id in t_terminated_emp_list, the record of the corresponding employee should move automatically from t_active_emp_details to t_past_emp_details
*/


-- Create the first table

create table t_active_emp_details
(
emp_id INT NOT NULL,
name VARCHAR(50) NOT NULL,
gender VARCHAR(50) NOT NULL,
age INT NOT NULL
)


-- Lets insert some values into the table

INSERT INTO t_active_emp_details
VALUES
(4, 'Ana', 'Female', 40),
(2, 'Jon', 'Male', 20),
(3, 'Mike', 'Male', 54),
(1, 'Sara', 'Female', 34),
(6, 'Bill', 'Male', 23),
(5, 'Nicky', 'Female', 29),
(7, 'Ruby', 'Female', 44)


-- Create the 2nd table
create table t_terminated_emp_list (emp_id INT)


-- Create the 3rd table
create table t_past_emp_details
(
emp_id INT NOT NULL,
name VARCHAR(50) NOT NULL,
gender VARCHAR(50) NOT NULL,
age INT NOT NULL
)


-- Create a trigger which will fire if a new value is inserted in termination list
-- the trigger should remove the employee from active list and move them into past list
create or alter trigger tr_trigger2
on t_terminated_emp_list
for insert
as
begin
	declare @id int
	select @id = emp_id from inserted
	
	insert into t_past_emp_details select * from t_active_emp_details where emp_id = @id
	delete from t_active_emp_details where emp_id = @id 
end


-- Check the existing values in the tables
-- We can run all 3 select below together if we want
select * from t_terminated_emp_list
select * from t_past_emp_details
select * from t_active_emp_details


-- Now terminate an employee and run the select again
insert into t_terminated_emp_list values (6)

