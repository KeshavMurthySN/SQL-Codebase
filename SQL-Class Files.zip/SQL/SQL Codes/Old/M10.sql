/* Topics for today:
		> SQL Execution Plan
		> Edureka assignment 6
		> Triggers
		> Bonus Topic - Using stored procedures and TVF in Tableau and Power BI
*/

---------------------------------------

-- Solution of Edureka Module 6 assignment

use Students

SET STATISTICS IO ON
SET STATISTICS TIME ON

select count(*) from CourseEnrollments

select COUNT(*) from CourseOfferings


select * from
CourseOfferings
left join CourseEnrollments
on CourseOfferings.CourseOfferingId = CourseEnrollments.CourseOfferingId
where TermCode = 'SP2016'



CREATE NONCLUSTERED INDEX ix_test
ON [dbo].[CourseEnrollments] ([CourseOfferingId])
INCLUDE ([StudentId],[Grade])



drop index CourseEnrollments.ix_test



SET STATISTICS IO OFF
SET STATISTICS TIME OFF


----------------------------------------






use HR_Edureka

/*

What is a trigger?


A trigger is a stored procedure in a database that automatically invokes whenever an event in the database occurs. 


What kind of events?
	1) Data Definition Language (DDL) events such as Create table, Create view, drop table, Drop view, and Alter table, etc.
	2) Data Manipulation Language (DML) events that begin with Insert, Update, and Delete.
	3) LOGON event. When a user session is created with a SQL Server instance after the authentication process of logging is finished but before establishing a user session, the LOGON event takes place.


Because a trigger cannot be called directly, unlike a stored procedure, it is referred to as a special procedure. A trigger is automatically called whenever a data modification event against a table takes place, which is the main distinction between a trigger and a procedure. Since a trigger cannot be called directly hence we cannot pass a parameter to it. 


Some of the benefits of using SQL triggers:
	> Data integrity: Triggers allow you to enforce complex business rules and constraints at the database level, ensuring that data remains consistent and accurate.
	> Automation: Triggers can automate repetitive or complex tasks by executing predefined actions whenever a specified event occurs. This reduces the need for manual intervention and improves efficiency.
	> Audit trails: Triggers can be used to track changes made to data, such as logging modifications in a separate audit table. This helps in auditing and maintaining a history of data changes.

*/

use HR_Edureka

-- Lets create a trigger which prevents deleting or creating tables in the database

-- before that lets try creating a table
create table temp
(ID int, Gender varchar(10), Age int)

-- Lets try deleting the table
drop table temp


-- Now lets create our trigger and then try creating the table again
create trigger tr_trigger1
on database    -- we can set it to on all server as well
for create_table -- we can also use alter_table, drop_table, etc.
as
begin
	rollback
	print 'Sorry. Hard Luck. Thats not allowed. My trigger will block you'
end


-- Now disable the trigger and try again
disable trigger tr_trigger1 on database


-- Now enable the trigger and try again
enable trigger tr_trigger1 on database


-- To delete the trigger permanently
drop trigger tr_trigger1 on database


/*
Next Problem Statement:

Create 3 tables 
	> t_active_emp_details to hold details of all employees currently employed
	> t_terminated_emp_list to hold a list of employee ids which have been terminated
	> t_past_emp_details to hold details of past employees

As soon as we enter an employee id in t_terminated_emp_list, the record of the corresponding employee should move automatically from t_active_emp_details to t_past_emp_details
*/


-- Create the first table

create table t_active_emp_details
(
emp_id INT NOT NULL,
name VARCHAR(50) NOT NULL,
gender VARCHAR(50) NOT NULL,
age INT NOT NULL
)


-- Lets insert some values into the table

INSERT INTO t_active_emp_details
VALUES
(4, 'Ana', 'Female', 40),
(2, 'Jon', 'Male', 20),
(3, 'Mike', 'Male', 54),
(1, 'Sara', 'Female', 34),
(6, 'Bill', 'Male', 23),
(5, 'Nicky', 'Female', 29),
(7, 'Ruby', 'Female', 44)


-- Create the 2nd table
create table t_terminated_emp_list (emp_id INT)


-- Create the 3rd table
create table t_past_emp_details
(
emp_id INT NOT NULL,
name VARCHAR(50) NOT NULL,
gender VARCHAR(50) NOT NULL,
age INT NOT NULL
)


-- Create a trigger which will fire if a new value is inserted in termination list
-- the trigger should remove the employee from active list and move them into past list
create trigger tr_trigger2
on t_terminated_emp_list
for insert
as
begin
	declare @id int
	select @id = emp_id from inserted
	
	insert into t_past_emp_details select * from t_active_emp_details where emp_id = @id
	delete from t_active_emp_details where emp_id = @id 
end


-- Check the existing values in the tables
-- We can run all 3 select below together if we want
select * from t_terminated_emp_list
select * from t_past_emp_details
select * from t_active_emp_details


-- Now terminate an employee and run the select again
insert into t_terminated_emp_list values (6)

