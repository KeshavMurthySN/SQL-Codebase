/* Topics for today:
		> Table valued functions
		> Indexes
		> Checking the Execution Plan
*/

--------------------------------------------

/*
Last week we learned about scalar user defined functions.
We learned that UDF are of two types:
1) Scalar functions - return a single data value
2) Table-valued functions - return a table
*/


use HR_Edureka

-- A quick recap of scalar UDF:
create function f_bonus(@Sal as float)
returns float
as
begin
	declare @bns float
	set @bns = @Sal * 0.1
	return @bns
end


---------------------------------------
/*
Simple definition of the table-valued function (TVF) - Its a user-defined function that returns a table data type and also it can accept parameters. 
TVFs can be used after the FROM clause in the SELECT statements so that we can use them just like a table in the queries.
The first thing that comes to our mind is that, what is the main difference between the view (Views are virtual tables that retrieve data from one or more physical tables) and TVF? 
Answer - The views do not allow parameterised usage, this is the essential difference between views and TVFs. 
*/

-------------------------------------

-- Demo: Create a new Table Valued Function
-- please note that it will always return a Table and there is no BEGIN - END statement
create function f_t_getEmpDetails(@empid as int)
returns table
as
return 
(
	select email, phone_number, salary from employees 
	where employee_id = @empid
)

-- use the function to fetch the records for employee number 101
select * from f_t_getEmpDetails(101)


-- Alter the function. We already restricted columns, now lets restrict rows as well
alter function f_t_getEmpDetails(@empid as int)
returns table
as
return 
(
	select email, phone_number, salary from employees 
	where department_id = 6
	and employee_id = @empid
)

-- Use the TVF to fetch the required data.
-- Employee ID 105 works in department number 6 
select * from f_t_getEmpDetails(105)

-- Employee ID 101 works in department number 9
select * from f_t_getEmpDetails(101)


-- To see the details about a function (like required parameters, etc) use the following stored procedure
sp_help f_t_getEmpDetails


-------------------------------------------
-- Index
-------------------------------------------

/*
An index is a database object. It is used by the server to speed up the retrieval of rows by using a pointer.
An index helps to speed up select queries and where clauses, but it slows down data input like the update, delete and the insert statements. Indexes can be created or dropped with no effect on the data. 

-----------------------------------------

Lets review the divide and conquer algorithm

-----------------------------------------

Syntax:
	CREATE INDEX index
	ON TABLE column;

and
	DROP INDEX index;

and 
	ALTER INDEX IndexName
	ON TableName;

----------------------------------------

In general, it�s a good practice to only create indexes on columns that are frequently used in queries and to avoid creating indexes on columns that are rarely used. It�s also a good idea to periodically review the indexes in your database and remove any that are no longer needed.

*/


-- Lets look at employee table
select * from employees

-- Lets say we are using the Salary column quite frequently in where clause
-- Lets create an index on salary columns to enhance the performance of our queries

create index ix_employee_salary
on employees (salary)


-- To list the indexes in a table, use the following stored procedure
sp_helpindex employees

-- To drop an index
drop index employees.ix_employee_salary

-- We can also use the Designer/GUI to do these things




/*
Different kinds of indexes in SQL Server:
https://learn.microsoft.com/en-us/sql/relational-databases/indexes/indexes?view=sql-server-ver16


We will be focusing on 3 of them
	Clustered
	Non - Clustered
	Unique


A clustered index is an index which defines the physical order in which table records are stored in a database. Since there can be only one way in which records are physically stored in a database table, there can be only one clustered index per table. By default a clustered index is created on a primary key column.

*/

-- Lets create a new table

CREATE TABLE tmp_employees
(
emp_id INT NOT NULL,
name VARCHAR(50) NOT NULL,
gender VARCHAR(50) NOT NULL,
age INT NOT NULL
)

-- Lets insert some values into the table
INSERT INTO tmp_employees
VALUES
(4, 'Ana', 'Female', 40),
(2, 'Jon', 'Male', 20),
(3, 'Mike', 'Male', 54),
(1, 'Sara', 'Female', 34),
(5, 'Nick', 'Female', 29)


-- Lets look at the records
select * from tmp_employees


-- Lets also check the current indexes in the table
sp_helpindex tmp_employees


-- Lets make emp_id a primary key
ALTER TABLE tmp_employees
ADD CONSTRAINT pk_tmp_emp_id PRIMARY KEY (emp_id)


-- Now look at the table again. Notice the sorting
select * from tmp_employees


-- Lets also check the current indexes in the table
sp_helpindex tmp_employees


-- We cannot use drop command on an index formed because of primary key
drop index tmp_employees.pk_tmp_emp_id


-- Lets remove the primary key constraint
ALTER TABLE tmp_employees DROP CONSTRAINT pk_tmp_emp_id

sp_helpindex tmp_employees



-- If there is no primary key then we can create our own custom clustered index
CREATE CLUSTERED INDEX ix_tmp_Employees_Age
ON tmp_Employees(age)


-- Now look at the table again. Notice the sorting
select * from tmp_employees


-- Lets also check the current indexes in the table
sp_helpindex tmp_employees


-- Dropping a non primary key clustered index can be done through drop command
drop index tmp_employees.ix_tmp_Employees_Age

sp_helpindex tmp_employees


------------------------------------

/*
Non-Clustered Indexes
A non-clustered index is also used to speed up search operations. Unlike a clustered index, a non-clustered index doesn�t physically define the order in which records are inserted into a table. In fact, a non-clustered index is stored in a separate location from the data table and hence there can be multiple non-clustered indexes per table.

To create a non-clustered index, you have to use the �CREATE NONCLUSTERED� statement. The rest of the syntax remains the same as the syntax for creating a clustered index. 
*/


-- Example
CREATE NONCLUSTERED INDEX ix_tmp_employees_Name
ON tmp_employees(name)


sp_helpindex tmp_employees


-- We can create as many non clustered index as required
CREATE NONCLUSTERED INDEX ix_tmp_employees_Age
ON tmp_employees(age)


-- We can also create an index with multiple columns
CREATE NONCLUSTERED INDEX ix_tmp_employees_NameAgeGender
ON tmp_employees(Name)
INCLUDE (gender,age)



/*
When to Use Clustered or Non-Clustered Indexes

1.   Number of Indexes
This is pretty obvious. If you need to create multiple indexes on your database, go for non-clustered index since there can be only one clustered index.

2.   SELECT Operations
If you want to select only the index value that is used to create and index, non-clustered indexes are faster. For example, if you have created an index on the �name� column and you want to select only the name, non-clustered indexes will quickly return the name.

However, if you want to select other column values such as age, gender using the name index, the SELECT operation will be slower since first the name will be searched from the index and then the reference to the actual table record will be used to search the age and gender.

On the other hand, with clustered indexes since all the records are already sorted, the SELECT operation is faster if the data is being selected from columns other than the column with clustered index.

3.   INSERT/UPDATE Operations
The INSERT and UPDATE operations are faster with non-clustered indexes since the actual records are not required to be sorted when an INSERT or UPDATE operation is performed. Rather only the non-clustered index needs updating.

4.   Disk Space
Since, non-clustered indexes are stored at a separate location than the original table, non-clustered indexes consume additional disk space. If disk space is a problem, use a clustered index.

*/


-------------------------------------------

-- Lets drop the indexes we created before

sp_helpindex tmp_employees

drop index tmp_employees.ix_tmp_employees_Name

drop index tmp_employees.ix_tmp_employees_Age

drop index tmp_employees.ix_tmp_employees_NameAge

sp_helpindex tmp_employees




-- Unique index is same as Unique constraint. 
ALTER TABLE tmp_employees
ADD CONSTRAINT UC_emp_Name UNIQUE (Name)

sp_helpindex tmp_employees

ALTER TABLE tmp_employees DROP CONSTRAINT UC_emp_Name



---------------------------------------

-- Solution of Edureka Module 6 assignment

use Students

SET STATISTICS IO ON
SET STATISTICS TIME ON

select count(*) from CourseEnrollments

select COUNT(*) from CourseOfferings


select * from
CourseOfferings
left join CourseEnrollments
on CourseOfferings.CourseOfferingId = CourseEnrollments.CourseOfferingId
where TermCode = 'SP2016'



CREATE NONCLUSTERED INDEX ix_test
ON [dbo].[CourseEnrollments] ([CourseOfferingId])
INCLUDE ([StudentId],[Grade])



drop index CourseEnrollments.ix_test



SET STATISTICS IO OFF
SET STATISTICS TIME OFF
