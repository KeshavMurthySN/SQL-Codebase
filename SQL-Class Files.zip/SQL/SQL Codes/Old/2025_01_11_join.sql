-- Join Types
--			Inner
--			Left
--			Full Outer
--			Self
--			Cross


drop database if exists demo_join
create database demo_join
go


use Demo_Join
go


create table tableau_course
(
	student_id int primary key,
	student_name varchar(20),
	tableau_score int
)
go


create table python_course
(
	student_id int primary key,
	student_name varchar(20),
	python_score int
)
go


insert into tableau_course
values
(1, 'Sam', 56),
(2, 'John', 77),
(3, 'Susan', 59),
(4, 'Alka', 87),
(5, 'Ricky', 45)
go


insert into python_course
values
(1, 'Sam', 74),
(3, 'Susan', 68),
(5, 'Ricky', 87),
(6, 'Anna', 64)
go


-- Question: Investigate both tables manually and answer the following:
--				How many students have enrolled for both courses?
--				How many students have enrolled for Tableau but not Python?
--				How many students have enrolled for Python but not Tableau?
--				How many total students do we have?



--inner join will give us students who have enrolled in both courses
select *
from tableau_course as t
inner join python_course as p
on t.student_id = p.student_id


--left join will give us all students from left table and only matching students from right table
select *
from tableau_course as t
left join python_course as p
on t.student_id = p.student_id


--Flip the position of the tables
select *
from python_course as p
left join tableau_course as t
on p.student_id = t.student_id


-- Full Outer Join gives us all rows from both the tables
select *
from tableau_course as t
full outer join python_course as p
on t.student_id = p.student_id



-- Another example of Inner and Left Join

use HR_2

select * from employees
select * from dependents


-- Show only those employees who has a dependent
select 
		concat(e.first_name,' ',e.last_name) as EmpName,
		concat(d.first_name,' ', d.last_name) as DepName
from employees as e
inner join dependents as d
on e.employee_id = d.employee_id



-- Show all employees. If an employee has a dependent, then show their name too.
select 
		concat(e.first_name,' ',e.last_name) as EmpName,
		concat(d.first_name,' ', d.last_name) as DepName
from employees as e
left join dependents as d
on e.employee_id = d.employee_id



-- self join

select * from employees

-- Question: Do a manual inspection and tell the manager name of Nancy Greenberg?

select e.email, m.email
from employees as e
inner join employees as m
on e.manager_id = m.employee_id



-- cross join

use demo_join


create table maincourse (
	dish varchar(30)
);

insert into maincourse values ('Pizza'), ('Burger'), ('Pasta');

select * from maincourse;

create table beverage(
	drink varchar(30)
);

insert into beverage values ('Pepsi'), ('Coke');

select * from beverage;


select dish, drink 
from maincourse
cross join beverage