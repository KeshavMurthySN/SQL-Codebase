-----------------------------------------------------------
------------------ Topics for Today ----------------------- 
-----------------------------------------------------------

/*
Inserting records in a database:
	Creating Database
	Deleting Database
	Creating Tables
	Defining Data Types
	Setting Primary Key
	Setting Foreign Key Relationship
	Inserting data into tables
	Deleting Data from tables
	Controlling transaction commit and rollback
	Updating existing data
	Creating new columns
	Deleting Columns
	Deleting Tables
	Copying the records of one table into another
*/



-- create a new database
create database Demo2



-- delete an existing database
-- drop database Demo2



-- How to check if a database exist
if (SELECT name FROM master.sys.sysdatabases WHERE name = 'Demo2') is null
	print 'no such db'
else
	print 'db present'



-- create a database if it doesn't exist
if (SELECT name FROM master.sys.sysdatabases WHERE name = 'Demo2') is null
	create database Demo2



-- Put the db in use
use Demo2



-- create a new table to store customer details
create table customer (
	cust_id int not null,
	cust_name varchar(30),
	cust_dob date
)



-- Check if a table already exist. If not, then create it
if (select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_NAME = 'customer') is null
create table customer (
	cust_id int not null,
	cust_name varchar(30),
	cust_dob date
)



-- insert data into the new table
insert into customer 
values
(1, 'Sam', '8 Jan 1985'),
(2, 'Bill', '4 Aug 1978'),
(3, 'Sarah', '15 July 1982'),
(4, 'Susan', '27 Nov 1988')



-- check if the value has been inserted
select * from customer


-- run the insert code above once again. Since there is no primary key the code should run
-- We should now have duplicate values. Run the select statement to check


-- delete duplicate rows
delete top(4) from customer


-- Alter the table to make cust_id as primary key
alter table customer
add constraint pk_cust primary key (cust_id)



-- If you want to remove primary key then use the code below
-- ALTER TABLE customer
-- DROP CONSTRAINT pk_cust



-- Add a new column
alter table customer
add cust_gender char(1)


-- To delete a column use drop command
-- ALTER TABLE customer
-- DROP COLUMN Gender


-- Lets see the table again
select * from customer



-- Lets set everyone's gender to Male
update customer set cust_gender = 'M'



-- Set Sarah's and Susan's gender as Female
update customer set cust_gender = 'F'
where cust_id in (3,4)



-- Make changes with a possibility of rollback
begin transaction
insert into customer (cust_id, cust_name, cust_gender)
values
(5, 'Chris', 'M'),
(6, 'Linda', 'F')
--commit
--rollback


-- check
select * from customer



-- delete required rows with a where clause
delete from customer
where cust_dob is null


-- question: how to delete all rows from a table?

-- create a new table 
create table item
(
	item_id int identity(1,1) primary key,
	item_name varchar(30) not null,
	item_price decimal(8,2)
)



-- insert values in the table
insert into item
values
('Pen', 8.5),
('Notebook', 150),
('Marker', 21.75)


-- check values
select * from item



-- create third table
create table sales
(
	sales_id int identity(1,1),
	customer_id int not null,
	item_id int not null,
	sales_qty int not null default 1,
	constraint pk_sales primary key (sales_id)
)



--insert data in sales table
insert into sales (customer_id, item_id, sales_qty)
values
(1,2,20),
(1,3,10),
(3,2,5),
(3,3,500),
(4,2,56),
(4,3,175)


--check sales table
select * from sales


-- add foreign key
alter table sales
ADD CONSTRAINT fk_sales_customer
FOREIGN KEY (customer_id) REFERENCES customer(cust_id)


-- add the next foreign key
alter table sales
ADD CONSTRAINT fk_sales_item
FOREIGN KEY (item_id) REFERENCES item(item_id)



-- create a new table from the records of another table
select * into f_cust
from customer
where cust_gender = 'F'


-- check
select * from f_cust


--insert the records of one table into another existing table
insert into f_cust
select * from customer where cust_id = 1



-- delete a table if it exists
drop table if exists f_cust



-------------------------------------------------------
----------------- Additional Code ---------------------
-------------------------------------------------------


-- Default value for a column
create table staff (
	staff_id int primary key,
	staff_name varchar(30) default 'John Doe',
	staff_doj date default getdate()
);

insert into staff (staff_id, staff_name, staff_doj) values (1, 'Sachin', '10 july 2018');
insert into staff (staff_id, staff_doj) values (2, '13 feb 2021');
insert into staff (staff_id, staff_name) values (3, 'Rahil');
insert into staff (staff_id, staff_name, staff_doj) values (4, NULL, NULL);
insert into staff (staff_id) values (5);


select * from staff;



-- cross join
create table maincourse (
	dish varchar(30)
);

insert into maincourse values ('Pizza'), ('Burger'), ('Pasta');

select * from maincourse;

create table beverage(
	drink varchar(30)
);

insert into beverage values ('Pepsi'), ('Coke');

select * from beverage;


select dish, drink 
from maincourse
cross join beverage