/* Topics for today:
	> Query Design through GUI
	> Built In functions
	> Stored Procedures
	> IF EXISTS / IF NOT EXISTS command
	> PRINT command
	> Other miscellaneous topics
*/

SELECT * FROM sys.databases


-- Check if the database doesn't already exist
-- If it does not exist then create it
if not exists(SELECT * FROM sys.databases WHERE name = 'HR_Edureka')
	create database HR_Edureka

	
-- Set the database in use
Use HR_Edureka


-- Task - run the script available at the following site:
-- https://www.sqltutorial.org/sql-sample-database/


-- Task - Inspect the tables to ensure that data has been populated

---------------------------------------------------------------
-- Query Builder GUI 
--------------------------------------------------------------

-- Task - Do an inner join of all tables. Fetch only the required columns. Name the view v_FullHrData

select * from v_FullHRData;



------------------------------------------------------------------------------
-- In-built functions
------------------------------------------------------------------------------

-- There are many inbuilt functions in SQL server. List below:
-- https://www.w3schools.com/sql/sql_ref_sqlserver.asp
-- These functions takes zero or more inputs/arguments, process it, and then gives an output
-- Each function has a specific syntax (grammar) which we need to adhere to


-- We use the SQL Server PRINT statement to return messages to the client. 
-- We specify the message as string expressions. SQL Server returns the message to the application.
print current_timestamp;

print 'Today is ' + cast(current_timestamp as varchar(50));

print concat('Today is ' ,current_timestamp);


-- CONCAT converts all arguments to string types before concatenation. 
-- CONCAT converts null values to empty strings.

print getdate();

print 'Today is ' + cast(getdate() as varchar(50));

print concat('Today is ', getdate());

-- getdate is exactly similar to current_timestamp but is t-sql specific
-- current_timestamp works in other databases too


-- Calculate Work Experience of each employee
select employee_id, email, hire_date, 
DATEDIFF(year, hire_date, getdate()) as WorkExp
from v_FullHRData;


-- Change hire_date value to make it more recent
update employees
set hire_date = DATEADD(year, 10, hire_date)


-- Values can also be updated through the view
update v_FullHRData
set hire_date = DATEADD(year, 10, hire_date)


-- Write an if else logic to classify employees as follows:
-- Employees with Hire_Date of 31st Dec 2010 or earlier should be classified as Vintage
-- Rest everyone should be classified as others
select employee_id, email, hire_date,
case
	when hire_date <= '31 Dec 2010' then 'Vintage'
	else 'Others'
end as ExperinceClass
from v_FullHRData;


-- Alternate solution
select employee_id, email, hire_date,
iif(hire_date <= '31 Dec 2010', 'Vintage', 'Others') as ExperinceClass
from v_FullHRData;


------------------------------------------------------------------
-- Stored Procedures
------------------------------------------------------------------

/* A stored procedure is a group of SQL statements that are created and stored in a database management system, 
allowing multiple users and programs to share and reuse the procedure. A stored procedure can accept 
input parameters, perform the defined operations, and return multiple output values. */

/* Syntax:
CREATE PROCEDURE procedure_name     (we can also use PROC)
AS 
BEGIN 
sql_statement 
END 
*/

/* Best Practices:
> Use SET NOCOUNT ON
> Use a consistent nomenclature like spABC (but not sp_ABC)
*/


-- create a simple stored procedure
create procedure spDemo1
as
begin
	select * from v_FullHRData where department_name = 'Sales'
end


-- Execute the stored procedure
spDemo1

-- or
exec spDemo1

-- or
execute spDemo1


/* When each statement is executed in a stored procedure, the SQL Server returns the number of rows 
that are affected as part of the results. To reduce network traffic and improve performance, 
use SET NOCOUNT ON at the beginning of the stored procedure.*/
create proc spDemo2
as
begin
	set nocount on
	select * from v_FullHRData where department_name = 'Sales'
end


-- Execute and look at the message window
exec spDemo2


-- There are some system stored procedures as well. We use sp_helptext to view our code
sp_helptext spDemo1

sp_helptext spDemo2


-- Below web page explains some other useful system stored procedures
-- https://www.sudshekhar.com/blog/useful-system-stored-procedure-in-sql


-- To modify a stored procedure use the alter command
alter proc spDemo2
as
begin
	set nocount on
	select * from v_FullHRData where department_name = 'IT'
end


-- To delete a stored procedure use the DROP command
drop proc spDemo2

-- or, just to play it safe
drop proc if exists spDemo2


-- we can encrypt a stored procedure
alter procedure spDemo1
with encryption    -- check out this new line
as
begin
	select * from v_FullHRData where department_name = 'Sales'
end

-- we can not see the logic inside the procedure now
sp_helptext spDemo1


-- Stored Procedures can accept input parameters
create proc spDemo3
	@DepName as varchar(50)
as
begin
	select * from v_FullHRData where department_name = @DepName
end


-- Execute the proc to get data for IT department
exec spDemo3 @DepName = 'IT'


-- Execute the proc to get data for Sales department
exec spDemo3 'Sales'


-- Stored Procedures can accept multiple input parameters
create proc spDemo4 
	@DepName as varchar(50), 
	@SalCutOff as int
as
begin
	select * from v_FullHRData where department_name = @DepName and salary > @SalCutOff
end

-- Implicit passing of parameter values. Order is important
exec spDemo4 'Sales', 7500

-- Explicit passing of parameter values
exec spDemo4 @SalCutOff = 5000, @DepName = 'IT'

