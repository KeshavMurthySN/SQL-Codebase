

use HR



-- Create a view which contains all required columns from multiple tables

CREATE VIEW v_FullEmpData
AS
SELECT employees.*, departments.department_name, departments.location_id, locations.street_address, locations.postal_code, 
		locations.city, locations.state_province, locations.country_id, countries.country_name, countries.region_id, regions.region_name, 
		jobs.job_title, jobs.min_salary, jobs.max_salary
FROM    employees 
		INNER JOIN departments ON employees.department_id = departments.department_id 
		INNER JOIN locations ON departments.location_id = locations.location_id 
		INNER JOIN countries ON locations.country_id = countries.country_id 
		INNER JOIN regions ON countries.region_id = regions.region_id 
		INNER JOIN jobs ON employees.job_id = jobs.job_id


-- How to create a temporary table

SELECT employees.*, departments.department_name, departments.location_id, locations.street_address, locations.postal_code, 
		locations.city, locations.state_province, locations.country_id, countries.country_name, countries.region_id, regions.region_name, 
		jobs.job_title, jobs.min_salary, jobs.max_salary
into #FullEmpDetails
FROM    employees 
		INNER JOIN departments ON employees.department_id = departments.department_id 
		INNER JOIN locations ON departments.location_id = locations.location_id 
		INNER JOIN countries ON locations.country_id = countries.country_id 
		INNER JOIN regions ON countries.region_id = regions.region_id 
		INNER JOIN jobs ON employees.job_id = jobs.job_id


select * from #FullEmpDetails




-- String functions

print 'A' + 'B'

print 1 + 2

print 'A' + 1

print concat('A' , 1)

print left('Hello', 3)

print right('Hello', 3)

print substring('Hello', 2, 3)

print lower('Hello')

print upper('Hello')

print len('Hello')


-- Create windows login ID. Logic - take first two characters from First Name and first two characters from last name

select	employee_id, first_name, last_name,
		LEFT(first_name,2) + left(last_name, 2) as WindowsID
from v_FullEmpData


-- we can also use the concat function

select	employee_id, first_name, last_name,
		concat(LEFT(first_name,2), left(last_name, 2)) as WindowsID
from v_FullEmpData


-- Modify the windows id to make it lower case

select	employee_id, first_name, last_name,
		lower(LEFT(first_name,2) + left(last_name, 2)) as WindowsID
from v_FullEmpData


-- Modify the windows id to add employee id at the end

select	employee_id, first_name, last_name,
		lower(concat(LEFT(first_name,2), left(last_name, 2), employee_id)) as WindowsID
from v_FullEmpData


-- Use the + operator for the above task

select	employee_id, first_name, last_name,
		lower(LEFT(first_name,2) + left(last_name, 2) + cast(employee_id as varchar)) as WindowsID
from v_FullEmpData



-- Date functions

-- Calculate Tenure of every employee

print getdate()

select employee_id, hire_date, DATEDIFF(year, hire_date, GETDATE()) as tenure
from employees


-- Assuming employees stays on probation for 6 months after their joining. Calculate confirmation date

select employee_id, hire_date, DATEADD(month, 6, hire_date) as ConfirmationDate
from employees


-- Logical functions

-- Categorise employees into 2 categories based on their income level

select employee_id, salary,
		iif(salary > 12000, 'High', 'Low') as IncomeLevel
from v_FullEmpData


-- Categorise employees into 3 categories based on their income level

select employee_id, salary,
		iif(salary > 12000, 'High', iif(salary > 8000, 'Mid', 'Low')) as IncomeLevel
from v_FullEmpData


-- Using case

select employee_id, salary,
		case
			when salary > 12000 then 'High'
			when salary > 8000 then 'Mid'
			else 'Low'
		end		as IncomeLevel
from v_FullEmpData



----------------------------------------------------------------
-- Meta data
----------------------------------------------------------------

-- To see the list of tables and views use the following command
select * from INFORMATION_SCHEMA.TABLES

-- In order to see columns within tables use following
select * from INFORMATION_SCHEMA.COLUMNS

-- To see how many columns a table has use following
select count(*) from INFORMATION_SCHEMA.COLUMNS
where TABLE_NAME = 'employees'

-- We can also use the following stored procedure to look at the metadata of an object
sp_help 'employees'


