/*
Topics for today

Inserting records in a database:
	 > Creating Database
	 > Deleting Database
	 > Creating Tables
	 > Defining Data Types
	 > Setting Primary Key
	 > Setting Foreign Key Relationship
	 > Inserting data into tables
	 > Deleting Data from tables
	 > Controlling transaction commit and rollback
	 > Updating existing data
	 > Creating new columns
	 > Deleting Columns
	 > Deleting Tables
	 > Copying the records of one table into another

Working with multiple tables:
	 > Union
	 > Joins
		 - Inner
		 - Left
		 - Full Outer
*/


-- Create a database
create database Demo2


-- Delete a database
drop database Demo2
--or
drop database if exists Demo2


-- Put the database in use
use Demo2


-- Create tables

create table courses (
	course_id int primary key,
	course_name varchar(30)
)



create table tableau (
	student_id int primary key,
	student_name varchar(30) not null,
	course_id int foreign key references courses(course_id),
	enrol_date date,
	score int
)



create table power_bi (
	student_id int primary key,
	student_name varchar(30) not null,
	course_id int foreign key references courses(course_id),
	enrol_date date,
	score int
)


-- insert data in the new tables
insert into courses (course_id, course_name)
values
(1, 'Data Viz using Tableau'),
(2, 'Microsoft Power BI'),
(3, 'Alteryx Data Prep'),
(4, 'Certified Scrum Master')


insert into tableau (student_id, student_name, course_id, enrol_date, score)
values
(101, 'Sam', 1, '12 Aug 2024', 88),
(104, 'Adam', 1, '25 May 2024', 45),
(105, 'Olga', 1, '9 Jan 2024', 95),
(108, 'Sarah', 1, '11 Oct 2024', 62),
(109, 'Bill', 1, '16 Feb 2024', 36),
(110, 'Susan', 1, '25 Apr 2024', 74)


insert into power_bi (student_id, student_name, course_id, enrol_date, score)
values
(102, 'Ken', 2, '1 Sep 2024', 67),
(103, 'Peter', 2, '5 Apr 2024', 89),
(104, 'Adam', 2, '12 June 2024', 66),
(106, 'Mary', 2, '16 Feb 2024', 85),
(107, 'Tom', 2, '11 May 2024', 36),
(109, 'Bill', 2, '21 Apr 2024', 58),
(110, 'Susan', 2, '27 Apr 2024', 68)


-- check the tables
select * from courses
select * from tableau
select * from power_bi


-- Alteryx course has been discontinued. Hence remove that row
delete from courses
where course_id = 3


-- check
select * from courses


-- Transactions are auto commited.
-- If we want to choose wether to commit or rollback a transaction

begin transaction

delete from courses
where course_id = 4

select * from courses

-- rollback
-- commit

-- Power BI course name has changed. 
update courses 
set course_name = 'Power BI Services' where course_id = 2


-- check
select * from courses


-- add a new column in course table
alter table courses
add instructor varchar(30)

-- check
select * from courses


-- delete the newly added column
alter table courses
drop column instructor


-- create a new table to store scholarship candidates (criteria: score >= 80)
select * into scholarship
from tableau
where score >= 80

-- check
select * from scholarship


-- insert data for Power bi students in the scholarship table
insert into scholarship
select * from power_bi where score >= 80


-- completely remove the scholarship table
drop table scholarship


-------------------------------------------------
---------------  Union --------------------------
-------------------------------------------------

-- Show all data

select * from tableau
union
select * from power_bi


-------------------------------------------------
-----------------  Joins ------------------------
-------------------------------------------------

-- inner join
select	
	tableau.student_id, 
	tableau.student_name, 
	tableau.score as 'Tableau Score', 
	power_bi.score as 'Power BI Score'
from tableau inner join power_bi
on tableau.student_id = power_bi.student_id



-- left join
select	
	tableau.student_id, 
	tableau.student_name, 
	tableau.score as 'Tableau Score', 
	power_bi.score as 'Power BI Score'
from tableau left join power_bi
on tableau.student_id = power_bi.student_id


-- left join the other way
select	
	power_bi.student_id, 
	power_bi.student_name, 
	tableau.score as 'Tableau Score', 
	power_bi.score as 'Power BI Score'
from power_bi left join tableau
on power_bi.student_id = tableau.student_id


-- full outer
select * 
from tableau full outer join power_bi
on tableau.student_id = power_bi.student_id