/* Topics for Today:

		Working with multiple tables:
			 > Union
			 > Joins
				 - Inner
				 - Left
				 - Full Outer
				 - Self Join
				 - Cross Join
			 > Except
			 > Intersect
			 > Join on NULL
			 > Join on Date
			 > Join on Inequality

*/

-- Put the correct db in use and inspect the tables

use Demo2
select * from tableau
select * from power_bi

-------------------------------------------------
---------------  Union --------------------------
-------------------------------------------------

-- Show all data

select * from tableau
union
select * from power_bi


-------------------------------------------------
-----------------  Joins ------------------------
-------------------------------------------------

-- inner join
select	
	tableau.student_id, 
	tableau.student_name, 
	tableau.score as 'Tableau Score', 
	power_bi.score as 'Power BI Score'
from tableau inner join power_bi
on tableau.student_id = power_bi.student_id



-- left join
select	
	tableau.student_id, 
	tableau.student_name, 
	tableau.score as 'Tableau Score', 
	power_bi.score as 'Power BI Score'
from tableau left join power_bi
on tableau.student_id = power_bi.student_id


-- left join the other way
select	
	power_bi.student_id, 
	power_bi.student_name, 
	tableau.score as 'Tableau Score', 
	power_bi.score as 'Power BI Score'
from power_bi left join tableau
on power_bi.student_id = tableau.student_id


-- full outer
select * 
from tableau full outer join power_bi
on tableau.student_id = power_bi.student_id


-- Q1: Produce the output as shown in the picture

-- Q2: Write a SQL to show details of those students who have enrolled only for Tableau

-- Q3: Write a SQL to show details of those students who have enrolled only for Power BI


--------------------------------------------------------
---------------  Self Join
--------------------------------------------------------

use HR_2
select * from employees

-- Question: Do a manual inspection and tell the manager name of Nancy Greenberg?

select e.email, m.email
from employees as e
inner join employees as m
on e.manager_id = m.employee_id


-- Q: Modify the above SQL to show only those employees who DO NOT have any manager


-----------------------------------------------------------
-----------  Cross Join
-----------------------------------------------------------

use Demo2


create table maincourse (
	dish varchar(30)
);

insert into maincourse values ('Pizza'), ('Burger'), ('Pasta');


create table beverage(
	drink varchar(30)
);

insert into beverage values ('Pepsi'), ('Coke');


select * from maincourse;
select * from beverage;

select dish, drink 
from maincourse
cross join beverage


------------------------------------------------------------
--------  Except and Intersect
------------------------------------------------------------

use Demo2

select * from tableau
select * from power_bi


-- Find students who has enrolled ONLY for tableau
select student_id, student_name from tableau
except
select student_id, student_name from power_bi


-- Find students who has enrolled ONLY for power BI
select student_id, student_name from power_bi
except
select student_id, student_name from tableau


-- Find students who has enrolled for BOTH
select student_id, student_name from tableau
intersect
select student_id, student_name from power_bi


USE Demo2

---------------------------------------------------------------------------
-------  Demo of Joins involving NULL values
---------------------------------------------------------------------------

if NULL = NULL
print('Equal')
else
print('Not Equal')


-- Create Employees Table
DROP TABLE if EXISTS Employees
CREATE TABLE Employees (
    employee_id INT,
    employee_name VARCHAR(255),
    department_id INT
);


-- Insert Data into Employees Table
INSERT INTO Employees (employee_id, employee_name, department_id) VALUES
(1, 'Alice', 101),
(2, 'Bob', 102),
(3, 'Carol', NULL),
(4, 'David', 101),
(5, 'Eve', NULL);


-- Create Departments Table
DROP TABLE if EXISTS Departments
CREATE TABLE Departments (
    department_id INT,
    department_name VARCHAR(255)
);


-- Insert Data into Departments Table
INSERT INTO Departments (department_id, department_name) VALUES
(101, 'Sales'),
(102, 'Marketing'),
(103, 'Engineering'),
(NULL, 'Unassigned'),
(NULL, 'Decomissioned');


-- Inner Join
SELECT * FROM Employees INNER JOIN Departments
on Employees.department_id = Departments.department_id


-- Left Join
SELECT * FROM Employees LEFT JOIN Departments
on Employees.department_id = Departments.department_id

-- Full Outer
SELECT * FROM Employees FULL OUTER JOIN Departments
on Employees.department_id = Departments.department_id



--------------------------------------------------------------------
----------  Demo of Joins on Date values
--------------------------------------------------------------------

-- Create tables
drop table if exists office_events
CREATE TABLE office_events (
    event_date DATE,
    event_name VARCHAR(50)
);

drop table if exists office_holidays
CREATE TABLE office_holidays (
    holiday_date DATE,
    holiday_name VARCHAR(50)
);

-- Insert data
INSERT INTO office_events VALUES 
('2025-03-10', 'Conference'), 
('2025-03-15', 'Workshop'),
('2025-04-08', 'Townhall'),
('2025-04-29', 'CEO Visit'),
('2025-05-18', 'Workshop'),
('2025-10-20', 'Family Day'),
('2025-11-15', 'Townhall');


INSERT INTO office_holidays VALUES 
('2025-01-14', 'Makar Sankranti'), 
('2025-03-15', 'Holi'), 
('2025-03-31', 'Eid-ul-Fitar'),
('2025-04-18', 'Good Friday'),
('2025-08-15', 'Independence Day'), 
('2025-10-20', 'Diwali');


-- Find dates on which both event & holiday is falling together
SELECT 
    e.event_name,
    h.holiday_name,
    e.event_date AS matched_date
FROM office_events e
INNER JOIN office_holidays h 
ON e.event_date = h.holiday_date;


-- Find events which are not happening on a holiday
SELECT 
    e.event_name,
    h.holiday_name,
    e.event_date 
FROM office_events e
LEFT JOIN office_holidays h 
ON e.event_date = h.holiday_date
where h.holiday_date is null


-- Find holidays on which there are no events
SELECT 
    h.holiday_name,
    h.holiday_date,
	e.event_name
FROM office_holidays h
LEFT JOIN office_events e 
ON h.holiday_date = e.event_date
where e.event_date is null


-----------------------------------------------
-------  Join on dates inequality
-----------------------------------------------

drop table if exists Tasks
CREATE TABLE Tasks (
    task_name VARCHAR(50),
    due_date DATE
);

drop table if exists Reviews
CREATE TABLE Reviews (
    review_date DATE,
    reviewer VARCHAR(50)
);

-- Insert data
INSERT INTO Tasks VALUES 
('Design', '2025-04-01'), 
('Testing', '2025-05-01');

INSERT INTO Reviews VALUES 
('2025-04-15', 'Alice'), 
('2025-05-10', 'Bob');

-- Find reviews which happened after the due date
SELECT 
    t.task_name,
    r.reviewer,
    t.due_date,
    r.review_date
FROM Tasks t
INNER JOIN Reviews r 
ON t.due_date < r.review_date;


-- Q: Work on the "Menu" creation again without using cross join

-- Q: Create match pairs for Champions Trophy