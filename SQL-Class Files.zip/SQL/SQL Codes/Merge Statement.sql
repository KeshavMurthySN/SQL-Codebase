

------------------------------------------------
---------   Merge Command
------------------------------------------------

/*

The MERGE statement runs insert, update, or delete operations on a target table from the results of a join with a source table. 


 Syntax:
MERGE <target_table> [AS TARGET]
USING <table_source> [AS SOURCE]
ON <search_condition>
[WHEN MATCHED 
   THEN <merge_matched> ]
[WHEN NOT MATCHED [BY TARGET]
   THEN <merge_not_matched> ]
[WHEN NOT MATCHED BY SOURCE
   THEN <merge_matched> ]; 


> Every MERGE statement must end with a semi-colon. If a semi-colon is not present at the end of the MERGE statement, then an error will be thrown 
> It is mandatory that one of the MATCHED clauses is provided in order for the MERGE statement to operate 

*/

use Demo2


drop table if exists prod_source
create table prod_source (
	id int,
	name varchar(20),
	price int
)


drop table if exists prod_target
create table prod_target (
	id int,
	name varchar(20),
	price int
)



insert into prod_source
values
(1, 'Pen', 30),
(3, 'Ref Book', 100),
(4, 'Calculator', 500)



insert into prod_target
values
(1, 'Pen', 20),
(2, 'Pencil', 10),
(3, 'Book', 115)

select * from prod_source
select * from prod_target


merge prod_target as t
using prod_source as s
on t.id = s.id
when matched then 
	update set t.name = s.name, t.price = s.price
when not matched by target then
	insert (id, name, price) values (s.id, s.name, s.price)
when not matched by source then
	delete;


-- If we do not use merge then we have to code these 3 operations separately

-- insert new records in prod_target
INSERT INTO prod_target (id, name, price)
SELECT s.id, s.name, s.price
FROM prod_source s
LEFT JOIN prod_target t ON s.id = t.id
WHERE t.id IS NULL


-- update matching records
UPDATE t
SET 
    t.name = s.name,
    t.price = s.price
FROM prod_target t
INNER JOIN prod_source s ON t.id = s.id


-- delete extra records of target table
DELETE FROM prod_target
WHERE id NOT IN (
    SELECT id FROM prod_source
)


