-- Create a new database named MotorsCertification

create database MotorsCertification

use MotorsCertification



-- Design a table/database object named orderdetails

create table orderdetails
(
	orderNumber int Primary Key,
	productCode varchar(50),
	quantityOrdered int,
	priceEach float,
	orderLineNumber smallint
)



-- Design a table/database object named customers

create table customers
(
	customerNumber int primary key,
	customerName varchar(50),
	contactLastName varchar(50),
	contactFirstName varchar(50),
	phone varchar(50),
	addressLine1 varchar(50),
	addressLine2 varchar(50),
	city varchar(50),
	state varchar(50),
	postalCode varchar(15),
	country varchar(50),
	salesRepEmployeeNumber int,
	creditLimit float
)




-- Design a table/database object named employees

create table employees
(
	employeeNumber int primary key,
	lastName varchar(50),
	firstName varchar(50),
	extension varchar(50),
	email varchar(50),
	officeCode varchar(50),
	reportsTo int,
	jobTitle varchar(50)
)




-- Design a table/database object named orders

create table orders
(
	orderNumber int primary key,
	orderDate date,
	requiredDate date,
	shippedDate date,
	status varchar(50),
	comments text,
	customerNumber int
)




-- Design a table/database object named offices

create table offices
(
	officeCode varchar(50) primary key,
	city varchar(50),
	phone varchar(50),
	addressLine1 varchar(50),
	addressLine2 varchar(50),
	state varchar(50),
	country varchar(50),
	postalCode varchar(50),
	territory varchar(50)
)



-- Design a table/database object named payments

create table payments
(
	customerNumber int primary key,
	checkNumber varchar(50),
	paymentDate date,
	amount float
)



-- Design a table/database object named productlines

create table productlines
(
	productLine varchar(50) primary key,
	textDescription varchar(4000),
	htmlDescription sql_variant,
	image sql_variant
)




-- Design a table/database object named products

create table products
(
	productCode varchar(50) primary key,
	productName varchar(50),
	productLine varchar(50),
	productScale varchar(50),
	productVendor varchar(50),
	productDescription text,
	quantityInStock smallint,
	buyPrice float,
	MSRP float
)




/* After designing the table insert records in the following orderdetails, employees, payments, products, customers, offices and orders table. */


-- Import from the orderdetails csv file
-- Steps - Delete if any record already exists in the table, then do bulk insert, then varify through a select statement

truncate table orderdetails
go

BULK INSERT orderdetails
FROM 'C:\Users\shash\Desktop\ST\Training\SQL\Assignments\00_Final Project\csv files\orderdetails.csv'
WITH
(
        FORMAT='CSV',
        FIRSTROW=2,
		ROWTERMINATOR = '0x0a'
)
go

select * from orderdetails
go



-- Import from the employees csv file
-- Please note that there is a NULL value to be cleaned in this file

truncate table employees
go
BULK INSERT employees
FROM 'C:\Users\shash\Desktop\ST\Training\SQL\Assignments\00_Final Project\csv files\employees.csv'
WITH
(
        FORMAT='CSV',
        FIRSTROW=2,
		ROWTERMINATOR = '0x0a'
)
go
select * from employees
go




-- Import from the payments csv file
-- Please note that the date values in this file are in dd-mm-yyyy format. This may cause problem
-- Hence check your local date settings through the following command
DBCC USEROPTIONS

-- If your dateformat is not dmy then set it to dmy
SET DATEFORMAT dmy;  

-- Now we can import the payments csv file
truncate table payments
go
BULK INSERT payments
FROM 'C:\Users\shash\Desktop\ST\Training\SQL\Assignments\00_Final Project\csv files\payments.csv'
WITH
(
        FORMAT='CSV',
        FIRSTROW=2,
		ROWTERMINATOR = '0x0a'
)
go
select * from payments
go


-- Import from the products csv file
-- csv contains text values under numeric columns. Clean them up manually

truncate table products
go
BULK INSERT products
FROM 'C:\Users\shash\Desktop\ST\Training\SQL\Assignments\00_Final Project\csv files\products.csv'
WITH
(
        FORMAT='CSV',
        FIRSTROW=2,
		ROWTERMINATOR = '0x0a'
)
go
select * from products 
go



/* After designing the table insert records in the following orderdetails, employees, payments, products, customers, offices and orders table. */


-- Insert data from customers.csv to the relevant table
-- Please note that there is a NULL value to be cleaned in this file

truncate table customers
go
BULK INSERT customers
FROM 'C:\Users\shash\Desktop\ST\Training\SQL\Assignments\00_Final Project\csv files\customers.csv'
WITH
(
        FORMAT='CSV',
        FIRSTROW=2,
		ROWTERMINATOR = '0x0a'
)
go
select * from customers
go



/* After designing the table insert records in the following orderdetails, employees, payments, products, customers, offices and orders table. */


truncate table offices
go
BULK INSERT offices
FROM 'C:\Users\shash\Desktop\ST\Training\SQL\Assignments\00_Final Project\csv files\offices.csv'
WITH
(
        FORMAT='CSV',
        FIRSTROW=2,
		ROWTERMINATOR = '0x0a'
)
go
select * from offices
go



-- Import from the orders csv file
-- Note that comments column has literal NULL values, which needs to be deleted from the csv file

truncate table orders
go
BULK INSERT orders
FROM 'C:\Users\shash\Desktop\ST\Training\SQL\Assignments\00_Final Project\csv files\orders.csv'
WITH
(
        FORMAT='CSV',
        FIRSTROW=2,
		ROWTERMINATOR = '0x0a'
)
go
select * from orders
go



-- Import from the productlines csv file

truncate table productlines
go
BULK INSERT productlines
FROM 'C:\Users\shash\Desktop\ST\Training\SQL\Assignments\00_Final Project\csv files\productlines.csv'
WITH
(
        FORMAT='CSV',
        FIRSTROW=2,
		ROWTERMINATOR = '0x0a'
)
go
select * from productlines
go



------------------------------------
-- Add the required foreign keys
------------------------------------

ALTER TABLE orderdetails with NOCHECK
ADD CONSTRAINT FK_orderdetails_products
FOREIGN KEY (productcode) REFERENCES products(productcode)


ALTER TABLE orderdetails with NOCHECK
ADD CONSTRAINT FK_orderdetails_orders
FOREIGN KEY (ordernumber) REFERENCES orders(ordernumber)


ALTER TABLE customers with NOCHECK
ADD CONSTRAINT FK_customers_employees
FOREIGN KEY (salesRepEmployeeNumber) REFERENCES employees(employeeNumber)


ALTER TABLE employees with NOCHECK
ADD CONSTRAINT FK_employees_employees
FOREIGN KEY (reportsTo) REFERENCES employees(employeeNumber)


ALTER TABLE employees with NOCHECK
ADD CONSTRAINT FK_employees_offices
FOREIGN KEY (officeCode) REFERENCES offices(officeCode)


ALTER TABLE orders with NOCHECK
ADD CONSTRAINT FK_orders_customers
FOREIGN KEY (customerNumber) REFERENCES customers(customerNumber)



ALTER TABLE payments with NOCHECK
ADD CONSTRAINT FK_payments_customers
FOREIGN KEY (customerNumber) REFERENCES customers(customerNumber)



ALTER TABLE products with NOCHECK
ADD CONSTRAINT FK_products_productlines
FOREIGN KEY (productLine) REFERENCES productlines(productLine)




--------------------------------
-- Create the required indexes
--------------------------------

CREATE NONCLUSTERED INDEX ix_orderdetails_productCode 
ON orderdetails (productCode)


CREATE NONCLUSTERED INDEX ix_employees_reportsTo 
ON employees (reportsTo)


CREATE NONCLUSTERED INDEX ix_employees_officeCode 
ON employees (officeCode)


CREATE NONCLUSTERED INDEX ix_orders_customerNumber 
ON orders (customerNumber)


CREATE NONCLUSTERED INDEX ix_products_productlines 
ON products (productLine)



-- Q4: Delete the columns in productlines which are useless that do not infer anything.

-- First inspect the table
select * from productlines

-- Now delete the two non-essential columns
alter table productlines drop column htmlDescription, image



-- Q5: Use a select statement to verify all insertions as well as updates

select * from customers
select * from employees
select * from offices
select * from orderdetails
select * from orders
select * from payments
select * from productlines
select * from products


-- Q6: Find out the highest and the lowest amount.

select MAX(amount) as HighestAmt, MIN(amount) as LowestAmt
from payments



-- Q7: Give the unique count of customerName from customers.

select count(distinct(customerName)) as DistCount from customers


-- Q8: Create a view from customers and payments named cust_payment and select customerName, amount, contactLastName, contactFirstName who have paid.Truncate and Drop the view after operation

create view cust_payment as
select customerName, amount, contactLastName, contactFirstName
from customers
inner join payments
on customers.customerNumber = payments.customerNumber


-- check the view
select * from cust_payment


-- drop the view
drop view cust_payment



-- Q9: Create a stored procedure on products which displays productLine for Classic Cars

create procedure spQ9
	@prodline as varchar(50)
as
begin
	select * from products inner join productlines
	on products.productLine = productlines.productLine
	where products.productLine = @prodline
end


-- Execute the stored procedure for Classic Cars
execute spQ9 'Classic Cars'




-- Q10: Create a function to get the creditLimit of customers less than 96800

create function f_creditLimit(@limit as float)
returns table
as
return 
(
	select * from customers 
	where creditLimit < @limit
)


-- Test the function
select * from f_creditLimit(96800)




-- Q11: Create Trigger to store transaction record for employee table which displays employeeNumber, lastName, FirstName and office code upon insertion

-- First create a table to store results from trigger
CREATE TABLE employee_insert_log (
    employeeNumber INT, 
    lastName VARCHAR(50), 
    firstName VARCHAR(50),
    officeCode VARCHAR(50), 
    timestamp DATETIME
)


-- Now lets create the trigger
create TRIGGER tr_employee_insert_audit
ON employees
AFTER INSERT
AS
BEGIN
    INSERT INTO employee_insert_log (employeeNumber, lastName, firstName, officeCode, timestamp)
    SELECT employeeNumber, lastName, firstName, officeCode, GETDATE() FROM inserted; 

	SELECT employeeNumber, lastName, firstName, officeCode, GETDATE() as timestamp FROM inserted;
END



-- Test the trigger

begin transaction

insert into employees (employeeNumber, lastName, firstName, extension, email, officeCode, reportsTo, jobTitle)
values (8764, 'Smith', 'Will', 'x6655', 'wsmith@classicmodelcars.com', '6', 1102, 'VP Sales')

-- uncomment & execute one of the options below to either rollback or commit
-- rollback
-- commit



-- Q12: Create a Trigger to display customer number if the amount is greater than 10,000

create TRIGGER tr_Q12
ON payments
AFTER INSERT, UPDATE
AS
BEGIN
	declare @val float
	declare @custNo int
	select @val = amount, @custNo = customerNumber from inserted
    if @val > 10000 
		print @custNo
	else
		print 'Amount is NOT greater than 10k'
END


-- Test the trigger

begin transaction
update payments set amount = 9000 where customerNumber = 102
rollback




-- Q13: Create Users, Roles and Logins according to 3 Roles: Admin, HR, and Employee. Admin can view full database and has full access, HR can view and access only employee and offices table. Employee can view all tables only.

-- Create Logins
-- Admin Login
CREATE LOGIN login_Admin WITH PASSWORD = 'EdurekaA';
GO

-- HR Login
CREATE LOGIN login_HR WITH PASSWORD = 'EdurekaH';
GO

-- Employee Login
CREATE LOGIN login_Employee WITH PASSWORD = 'EdurekaE';
GO


-- Create Users
-- Admin User
CREATE USER u_Admin FOR LOGIN login_Admin;
GO

-- HR User
CREATE USER u_HR FOR LOGIN login_HR;
GO

-- Employee User
CREATE USER u_Employee FOR LOGIN login_Employee;
GO



-- Add users to pre-defined roles

ALTER ROLE db_owner ADD MEMBER u_Admin;
GO

ALTER ROLE db_datareader ADD MEMBER u_Employee;
GO



-- create a user defined role for HR

create role udr_HR
go

grant select on employees
to udr_HR
go

grant select on offices
to udr_HR
go

ALTER ROLE udr_HR ADD MEMBER u_HR
go




-- Q14: Schedule a Job which backups and schedule it according to developer preference.
-- Answer: See the word document



-- Q15: Open Activity Monitor and list down some minor observations including Processes, Resource Waits, and Active Expensive Queries.
-- https://www.youtube.com/watch?v=5r1swGCcwT4