use Students


-- Task1:Perform Left Join on CourseOfferings and CourseEnrollments to find the TermCode= �SP2016�

-- Make yourself familiar with the table and its values
select * from CourseOfferings


-- Make yourself familiar with the table and its values
-- Please note the large number of rows and the time to execute the query
select * from CourseEnrollments


-- Turn on the execution plan window

select * from CourseOfferings
left join CourseEnrollments
on CourseOfferings.CourseOfferingId = CourseEnrollments.CourseOfferingId
where TermCode = 'SP2016'


-- Task 2:Re-Run the above command with

SET STATISTICS IO ON

SET STATISTICS TIME ON



-- Youtube video on indexes and 8 kb data pages - https://www.youtube.com/watch?v=Oj9Vx6FjoIc

CREATE NONCLUSTERED INDEX ix_test
ON [dbo].[CourseEnrollments] ([CourseOfferingId])
INCLUDE ([StudentId],[Grade])


drop index CourseEnrollments.ix_test


SET STATISTICS IO OFF
SET STATISTICS TIME OFF
