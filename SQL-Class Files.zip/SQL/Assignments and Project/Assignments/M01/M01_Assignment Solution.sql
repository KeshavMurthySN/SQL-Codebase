-- Solution to Edureka Module 1 assignment

/* Design an ER-Model describing the Student_Details database.This Database comprises the following 5 tables called: 
Student, Department, Lecturer, Subject, and Hobby.*/

-- Check if the database already doesnt exist. 
-- If it does not exist then create the database

create database Student_Details


-- Put the db in use

use Student_Details


-- Create the Student Table

create table Student (
Student_ID int not null primary key,
DOB date,
Student_Name varchar(50),
Batch varchar(50),
Department_ID int
)


-- Create the Department Table

create table Department (
Department_ID int not null primary key,
Department_Name varchar(50)
)



-- Create the Lecturer Table

create table Lecturer (
Lecturer_ID int not null primary key,
Lecturer_Name varchar(50),
Department_ID int
)



-- Create the Subject Table

create table Subject (
Subject_ID int not null primary key,
Subject_Name varchar(50),
Lecturer_ID int
)



-- Create the Hobby Table

create table Hobby (
Student_ID int,
Hobby varchar(50)
)



-- Add a foreign key
ALTER TABLE Student
ADD CONSTRAINT fk_Student_Dept
FOREIGN KEY (Department_ID) REFERENCES Department(Department_ID)


-- Add a foreign key
ALTER TABLE Lecturer
ADD CONSTRAINT fk_Lecturer_Dept
FOREIGN KEY (Department_ID) REFERENCES Department(Department_ID)


-- Add a foreign key
ALTER TABLE Subject
ADD CONSTRAINT fk_Subject_Lecturer
FOREIGN KEY (Lecturer_ID) REFERENCES Lecturer(Lecturer_ID)


-- Add a foreign key
ALTER TABLE Hobby
ADD CONSTRAINT fk_Hobby_Student
FOREIGN KEY (Student_ID) REFERENCES Student(Student_ID)


-- After executing all the codes above we can goto the Database Diagrams folder to generate an ERD