-------------------------------------------------------------
/* Topics:
		Single Line vs Multi Line comment
		Creating database
		Creating table with required columns
		Inserting values into the table
		Removing all rows from a table
		Removing the entire table
		Removing some rows from a table
		Sub - Query
		Views
		Revision of Join
		Revision of Union
		Creating new columns through mathematical calculations
		In built functions
		IF THEN ELSE calculation
		Using SQL generator
		Please Note - This code can also be used for module 3 assignment with some modifications
*/
-------------------------------------------------------------


-- create a new database
create database SkillDB;


-- put the new database in use
use SkillDB


-- create the first table with required columns
create table MS_SQL_Server (
Emp_ID int not null primary key,
Emp_Name varchar(50) not null,
Department varchar(30),
Gender char(1),
Skill_Level int
)


-- create the second table with required columns
create table Tableau (
Emp_ID int not null primary key,
Emp_Name varchar(50) not null,
Department varchar(30),
Gender char(1),
Skill_Level int
)


-- create the third table with required columns
create table Python (
Emp_ID int not null primary key,
Emp_Name varchar(50) not null,
Department varchar(30),
Gender char(1),
Skill_Level int
)


-- create the forth table with required columns
create table EmployeeContactDetails (
Emp_ID int not null primary key,
Emp_Name varchar(50) not null,
Mobile char(10),
Email varchar(50)
)


-- Insert the details of employee who are expert in MS SQL server
insert into MS_SQL_Server
values
(1, 'Janice Fletcher', 'Finance', 'F', 24),
(5, 'Leon Gill', 'Technology', 'M', 35),
(6, 'Melanie Garner', 'Sales', 'F', 43),
(8, 'Meredith Norris Thomas', 'Finance', 'M', 31),
(9, 'Marcus Dunlap', 'Finance', 'M', 58),
(10, 'Kara Pace', 'HR', 'F', 34),
(12, 'Timothy Reese', 'Finance', 'M', 50),
(14, 'Florence Hsu Schwarz', 'Sales', 'M', 31),
(16, 'Jim Rodgers', 'Sales', 'M', 47),
(17, 'Marion Nolan Kaplan', 'Technology', 'M', 31),
(19, 'Lynn Moss', 'Finance', 'M', 51),
(20, 'Edna Thomas', 'Technology', 'F', 57),
(21, 'Virginia Hardison', 'Sales', 'M', 32),
(22, 'Marguerite Kane', 'Sales', 'M', 32),
(24, 'Ronnie McNamara', 'HR', 'M', 32),
(26, 'Alice Capps', 'Finance', 'F', 26),
(28, 'Ricky Hensley', 'HR', 'M', 51),
(31, 'Stacy Chandler', 'Technology', 'F', 58),
(33, 'Seth Grimes', 'Finance', 'M', 38),
(34, 'Alexandra Fuller', 'Technology', 'M', 46),
(36, 'Melinda Sloan', 'Technology', 'F', 44),
(37, 'Anne Nguyen', 'Sales', 'F', 60),
(38, 'Geoffrey Hewitt', 'HR', 'M', 21),
(42, 'Sidney Russell Austin', 'Finance', 'M', 55),
(44, 'Randall Montgomery', 'Technology', 'M', 41),
(45, 'Kimberly Epstein', 'HR', 'F', 40),
(46, 'Rose Lassiter', 'Finance', 'F', 43),
(47, 'Sheila Warren', 'Technology', 'F', 34),
(49, 'Pam Gilbert', 'HR', 'F', 39),
(51, 'Lynn Morrow', 'Finance', 'M', 38)



-- Check if all the rows have been successfully entered
select  * from MS_SQL_Server


-- Remove all the rows but do not delete the table
delete from MS_SQL_Server


-- Delete the entire table structure
drop table MS_SQL_Server


-- Remove selected rows from a table
delete from MS_SQL_Server
where gender = 'F'


-- Insert rows for employees who are Tableau expert
insert into Tableau
values
(2, 'Bonnie Potter', 'Finance', 'M', 44),
(3, 'Ronnie Proctor', 'Technology', 'M', 25),
(4, 'Dwight Hwang', 'Sales', 'M', 40),
(5, 'Leon Gill', 'Technology', 'M', 35),
(6, 'Melanie Garner', 'Sales', 'F', 43),
(7, 'Lorraine Houston', 'HR', 'M', 52),
(10, 'Kara Pace', 'HR', 'F', 34),
(11, 'Gwendolyn F Tyson', 'Sales', 'M', 25),
(13, 'Sarah Ramsey', 'HR', 'F', 59),
(15, 'Laurie Hanna', 'Finance', 'F', 40),
(16, 'Jim Rodgers', 'Sales', 'M', 47),
(19, 'Lynn Moss', 'Finance', 'M', 51),
(20, 'Edna Thomas', 'Technology', 'F', 57),
(22, 'Marguerite Kane', 'Sales', 'M', 32),
(23, 'Guy Gallagher', 'Technology', 'M', 22),
(25, 'Elizabeth Walker', 'Sales', 'F', 42),
(26, 'Alice Capps', 'Finance', 'F', 26),
(27, 'Matthew Berman', 'Finance', 'M', 41),
(29, 'Milton Bland', 'Finance', 'M', 21),
(30, 'Ray Morgan', 'Technology', 'M', 36),
(31, 'Stacy Chandler', 'Technology', 'F', 58),
(33, 'Seth Grimes', 'Finance', 'M', 38),
(34, 'Alexandra Fuller', 'Technology', 'M', 46),
(37, 'Anne Nguyen', 'Sales', 'F', 60),
(38, 'Geoffrey Hewitt', 'HR', 'M', 21),
(39, 'Terri Lyons', 'Technology', 'F', 38),
(43, 'Marvin Hawley', 'HR', 'M', 27),
(46, 'Rose Lassiter', 'Finance', 'F', 43),
(47, 'Sheila Warren', 'Technology', 'F', 34),
(48, 'Charlotte Stanton', 'Finance', 'F', 48),
(49, 'Pam Gilbert', 'HR', 'F', 39),
(50, 'Gene Diaz', 'Technology', 'M', 29),
(51, 'Lynn Morrow', 'Finance', 'M', 38),
(53, 'Arlene Rouse', 'Sales', 'M', 47),
(54, 'Ellen McCormick', 'Finance', 'M', 44)



-- Check the Tableau table to ensure all values have been inserted correctly
select * from Tableau



-- Insert rows of employees who are Python expert
insert into Python
values
(1, 'Janice Fletcher', 'Finance', 'F', 24),
(2, 'Bonnie Potter', 'Finance', 'M', 44),
(7, 'Lorraine Houston', 'HR', 'M', 52),
(8, 'Meredith Norris Thomas', 'Finance', 'M', 31),
(10, 'Kara Pace', 'HR', 'F', 34),
(11, 'Gwendolyn F Tyson', 'Sales', 'M', 25),
(12, 'Timothy Reese', 'Finance', 'M', 50),
(18, 'Tony Wilkins Winters', 'Technology', 'M', 53),
(20, 'Edna Thomas', 'Technology', 'F', 57),
(22, 'Marguerite Kane', 'Sales', 'M', 32),
(23, 'Guy Gallagher', 'Technology', 'M', 22),
(24, 'Ronnie McNamara', 'HR', 'M', 32),
(25, 'Elizabeth Walker', 'Sales', 'F', 42),
(26, 'Alice Capps', 'Finance', 'F', 26),
(27, 'Matthew Berman', 'Finance', 'M', 41),
(28, 'Ricky Hensley', 'HR', 'M', 51),
(29, 'Milton Bland', 'Finance', 'M', 21),
(32, 'Ian L ODonnell', 'HR', 'M', 29),
(35, 'Theodore Moran', 'Finance', 'M', 54),
(40, 'Dawn Bailey', 'Finance', 'M', 38),
(41, 'Lorraine Kelly', 'Sales', 'F', 37),
(45, 'Kimberly Epstein', 'HR', 'F', 40),
(50, 'Gene Diaz', 'Technology', 'M', 29),
(52, 'Jenny Sanchez', 'HR', 'F', 25),
(53, 'Arlene Rouse', 'Sales', 'M', 47)



-- Fetch the Python table
select * from Python



/* Get all the records from the Tableau table where the Skill Level of the employees 
should be greater than the maximum value of the Skill level in the Python table */

-- In other words - get a list of Tableau users who are better than the best Python user

-- Lets break the above problem into small parts

-- Part 1: Max skill level in Python
select max(Skill_Level) from Python

-- we get 57 as the answer in above query
-- now lets check which Tableau users have a skill of beyond 57

select * from Tableau
where Skill_Level > 57

-- Now lets combine the two steps into one using sub-query
select * from Tableau
where Skill_Level > (select max(Skill_Level) from Python)




/* Get all the records from the Tableau table where the skill level is 
greater than at leaste one value from the skill level column of the Python table */

-- In other words - get a list of Tableau users who are better than at leaste one python user

-- Lets break the above problem into small parts

-- Part 1: Minimum skill level in Python
select min(Skill_Level) from Python

-- we get 21 as the answer in above query
-- now lets check which Tableau users have a skill of beyond 21

select * from Tableau
where Skill_Level > 21

-- Now lets combine the two steps into one using sub-query
select * from Tableau
where Skill_Level > (select min(Skill_Level) from Python)



-- Add the contact detail of employee in table named EmployeeContactDetails.
insert into EmployeeContactDetails
values
(1, 'Janice Fletcher', '9771877099', 'Jancher@xyz.com'),
(4, 'Dwight Hwang', '9812275957', 'Dwiwang@xyz.com'),
(7, 'Lorraine Houston', '9805938759', 'Lorston@xyz.com'),
(8, 'Meredith Norris Thomas', '9304447855', 'Meromas@xyz.com'),
(9, 'Marcus Dunlap', '9778090073', 'Marnlap@xyz.com'),
(12, 'Timothy Reese', '9728509673', 'Timeese@xyz.com'),
(17, 'Marion Nolan Kaplan', '9856186677', 'Marplan@xyz.com'),
(18, 'Tony Wilkins Winters', '9818587396', 'Tonters@xyz.com'),
(23, 'Guy Gallagher', '9088931999', 'Guygher@xyz.com'),
(35, 'Theodore Moran', '9515695811', 'Theoran@xyz.com'),
(37, 'Anne Nguyen', '9035369330', 'Annuyen@xyz.com'),
(38, 'Geoffrey Hewitt', '9057763500', 'Geowitt@xyz.com'),
(48, 'Charlotte Stanton', '9602233286', 'Chanton@xyz.com'),
(49, 'Pam Gilbert', '9385817957', 'Pambert@xyz.com'),
(52, 'Jenny Sanchez', '9324502816', 'Jenchez@xyz.com'),
(54, 'Ellen McCormick', '9531039688', 'Ellmick@xyz.com')



-- check if the values have been inserted correctly in the table
select * from EmployeeContactDetails



/* Get all the records from the Tableau table where there is at least
one record in the EmployeeContactDetails table with a matching employee�s EmployeeID */

-- In other words - Fetch a list of Tableau users whose contact details are available with us

-- Two ways to solve this problem - we can use Join or we can use sub query

-- Lets use join first
select Tableau.* from Tableau
inner join EmployeeContactDetails
on Tableau.Emp_ID = EmployeeContactDetails.Emp_ID

-- Please note that Tableau.* will return columns only from Tableau table
-- vs * will return columns from both tables

-- Now lets use sub query
select * from Tableau 
where Emp_ID in (select Emp_ID from EmployeeContactDetails)

-- Notice that both the queries gives same results



/* Combine users of Tableau, Python and MS SQL Server and merge them and sort by their names */
select * from Tableau
union
select * from Python
union
select * from MS_SQL_Server
order by Emp_Name


-- Would you also like to show the skills of every user?
select *, 'Tableau' as Skill from Tableau
union
select *, 'Python' as Skill from Python
union
select *, 'SQL Server' as Skill from MS_SQL_Server
order by Emp_Name

-- Notice the difference between number of rows. Can you answer why this difference?


-- Above query is useful and we foresee it being used extensively in different ways
-- So lets save this query as a View
-- View makes our work easier. We save a query as a view and reutilise it as and when required.
-- This saves our coding effort

create view v_AllSkills 
as
select *, 'Tableau' as Skill from Tableau
union
select *, 'Python' as Skill from Python
union
select *, 'SQL Server' as Skill from MS_SQL_Server


-- Select all records from the view
select * from v_AllSkills




-- Example of a mathematical calculation
-- Calculate the percentage score using skill level
-- skill level is measured through a technical test. 
-- The maximum marks which can be scored in this test is 60

select *, Skill_Level*100/60 as Percentage_Score
from v_AllSkills



-- Example of if else case
-- If the skill level is less than 30 then classify the person as novice
-- If skill level is between 30 to 45 then classify the person as power user
-- If skill level is above 45 then classify the person as expert

select *,
case
	when Skill_Level < 30 then 'Novice'
	when Skill_Level < 45 then 'Power User'
	else 'Expert'
end as SkillClass
from v_AllSkills

-- As we have created a view, hence we are able to refer to the combined employee population very easily




/* Retrieve all of the rows from Table Tableau that exist in Table of Python, and retrieving all data 
of the rows from Python that exist in the Table of MS_SQL_Server and it should be sorted by Names */ 

select Tableau.* from Tableau inner join Python on Tableau.Emp_ID = Python.Emp_ID
union
select Python.* from Python inner join MS_SQL_Server on Python.Emp_ID = MS_SQL_Server.Emp_ID
order by Emp_Name

