-- Create a new database
Create database Assignment_5;


-- Use database
use Assignment_5


-- Delete a database. But its better to use the SSMS UI
DROP database Assignment_5;


-- Create Movies table
Create table Movies (
Code int not null PRIMARY KEY,
Title varchar(30) not null,
Rating varchar(30)
)


-- Create MovieTheaters table 
Create table MovieTheaters (
Code int not null PRIMARY key,
Name varchar(30) not null,
Movie int 
)


-- Add a foreign key
ALTER TABLE MovieTheaters 
ADD CONSTRAINT fk_Movies_Code
FOREIGN KEY (Movie) REFERENCES Movies(Code)


-- Remove the check so that data can be manipulated without errors
ALTER TABLE MovieTheaters NOCHECK CONSTRAINT ALL


-- delete a table
DROP table MovieTheaters


-- Delete all rows but keep the table
delete from Movies


-- We can also use. 
truncate table Movies


-- Delete command is a DML statement. Truncate is a DDL statement.
-- Delete can be used with where clause to remove particular rows and not all records
-- Truncate always will delete all records



-- Insert Rows in the Movie Table
insert into Movies
values
(9,'Citizen King','G'),
(1,'Citizen Kane','PG'),
(2,'Singin in the Rain','G'),
(3,'The Wizard of Oz','G'),
(4,'The Quiet Man',NULL),
(5,'North by Northwest',NULL),
(6,'The Last Tango in Paris','NC-17'),
(7,'Some Like it Hot','PG-13'),
(8,'A Night at the Opera',NULL);


-- Insert rows in MovieTheaters Table
insert into MovieTheaters
values
(1, 'Odeon',5),
(2, 'Imperial',1),
(3, 'Majestic', NULL),
(4, 'Royale', 6),
(5, 'Paraiso', 3),
(6, 'Nickelodeon', NULL);


--Show the title of all the
-- movies from the Movies Table.
select Title from Movies


/*Show all the data from all movie theatres and, additionally, 
the data from the movie that is being shown in the theatre (if one is being shown)*/
select * from MovieTheaters
left join Movies
on MovieTheaters.Movie = Movies.Code


/*Select all data from all movies and, if that movie 
is being shown in a theatre, show the data from the theatre.*/
select * from Movies
left join MovieTheaters
on Movies.Code = MovieTheaters.Movie


--Show the titles of movies not currently being shown in any theatres
select Title from Movies
left join MovieTheaters
on Movies.Code = MovieTheaters.Movie
where MovieTheaters.Code is null


--Add the unrated movie "One, Two, Three"to the Movie Table
insert into Movies
values
(10, 'One, Two, Three',null)


--Remove movie projecting movies rated "NC-17"
delete from Movies
where Rating = 'NC-17'


--Set the rating of all unrated movies to "G"
UPDATE movies
SET Rating = 'G'
WHERE Rating is null;