-- Module 4 assignment solution
-- The database is available on Edureka LMS under module 4

use Sample;


-- Get all rows of the works_on table
select * from works_on;


-- Get the employee numbers for all clerks
select * from works_on where job = 'Clerk';


-- Get the employee numbers for employees working on project p2 
-- and having employee numbers lower than 10005.    
select * from works_on
where project_no = 'P2' and emp_no < 10005;


-- Get the employee numbers for employees who didn�t enter their project in 2017
select * from works_on
where YEAR(enter_date) <> 2017;


-- Get the employee numbers for all employees who 
-- have a leading job (i.e., Analyst or Manager) in project p1
select * from works_on
where job in ('Manager', 'Analyst')
and project_no = 'P1';


-- Get the enter dates for all employees in project p2 whose jobs have not been determined yet.
-- Please note that in this table NULL values are stored as string text NULL
select * from works_on
where project_no = 'P2' and job = 'NULL';


-- Get the employee numbers and last names of all employees whose first names contain two letter t�s
select * from employee
where (LEN(emp_fname) - LEN(REPLACE(emp_fname, 't', ''))) = 2;


-- Find the employee numbers of all employees whose department is located in Delhi
select * from employee
inner join department
on employee.dept_no = department.dept_no
where department.location = 'Delhi';


-- Group all departments using their locations
select location, count(*) as CountOfDept
from department
group by location;


-- Get the jobs that are done by more than two employees.
select job, count(*) as NoOfEmps
from works_on
group by job
having count(*)>2;
