-- Module 5 Assignment Code. 
-- For looking at the problem statements go to Edureka's LMS


-- Create a database named �Assignment_51�

if not exists(SELECT * FROM sys.databases WHERE name = 'Assignment_51')
	create database Assignment_51


use Assignment_51


-- Create a database object named Student with three attributes/columns
-- Check if the table exists. If not then create it
IF OBJECT_ID('Student', 'U') IS NULL
	create table Student (
		Rno int not null primary key,
		Marks varchar(50) not null,
		Name varchar(50)
	)


-- Populate the table with data with at least 7 entries
insert into Student
values
(1,'20','Amit'),
(2,'60','Sam'),
(3,'40','Rio'),
(4,'60','Ram'),
(5,'40','Geeta'),
(6,'20','Prem'),
(7,'60','Bill'),
(8,'60','Chris'),
(9,'40','Susan');

-- Check if the data has been inserted properly
select * from Student


-- Create a database object named Subject with three attributes/columns
IF OBJECT_ID('Subject', 'U') IS NULL
	create table Subject (
		Rno int not null primary key,
		Subject1 varchar(50) not null,
		Subject2 varchar(50) not null,
		Subject3 varchar(50) not null
	)


-- Populate the table with data with at least 7 entries
insert into Subject
values
(1,'20','15','14'),
(2,'29','11','14'),
(3,'11','11','25'),
(4,'14','19','30'),
(5,'15','14','11'),
(6,'30','19','22'),
(7,'17','10','15'),
(8,'13','21','23'),
(9,'15','14','28');


-- Check if the data has been inserted properly
select * from Subject



-- Create a function where GetStudent(@Rno INT) returns the name of the student if a 
-- print statement is used to call the function.

create function GetStudent(@Rno as int)
returns varchar(50)
as
begin
	return (select name from Student where Rno = @Rno)
end


-- test the function
print dbo.GetStudent(2)

print dbo.GetStudent(5)



-- Create a function to get the names of all the students where marks are equal to a specified number (e.g., 60)
create function fMarksEqual(@mrk as int)
returns table
as
return (select name from Student where Marks = cast(@mrk as varchar(50)))

-- Test the function
select * from fMarksEqual(60)



-- Create a function GetAvg(@Name)to get the average marks of students 
-- across all subjects whose name is specified in the function

create function GetAvg(@Name as varchar(50))
returns table
as
return (
	select 
		Name, Subject1, Subject2, Subject3,
		(cast(Subject1 as float) + cast(Subject2 as float) + cast(Subject3 as float))/3 as Average
	from Student
	inner join Subject
	on Student.Rno = Subject.Rno
	where Student.Name = @Name
)

-- Test the function
select * from GetAvg('Ram')