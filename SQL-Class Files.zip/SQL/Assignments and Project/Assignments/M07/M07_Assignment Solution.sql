-- Solution to Edureka assignment number 7
-- Before using this code check if "Sample" database exists 
-- If it exists then delete it

create database Sample
GO

USE Sample
GO


-- Q1: Create a table named department with 3 attributes/columns

CREATE TABLE department(
	dept_no varchar(255) NULL,
	dept_name varchar(255) NULL,
	location varchar(255) NULL
)
GO



-- Q2: Create a table named as employee with 4 attributes/columns

CREATE TABLE employee(
	emp_no int NULL,
	emp_fname varchar(255) NULL,
	emp_lname varchar(255) NULL,
	dept_no varchar(255) NULL
) 
GO



-- Q3: Create a table named as project with 3 attributes/columns

CREATE TABLE project(
	project_no varchar(255) NULL,
	project_name varchar(255) NULL,
	budget int NULL
) 
GO


-- Q4: Create a table named as works_on with 4 attributes/columns

CREATE TABLE works_on(
	emp_no int NULL,
	project_no varchar(255) NULL,
	job varchar(255) NULL,
	enter_date date NULL
) 
GO



-- Q5: Insert the values in all the respective tables

INSERT into department (dept_no, dept_name, location) 
VALUES 
('d1', 'Research', 'Delhi'), 
('d2', 'Accounting', 'Mumbai'),
('d3', 'Marketing', 'Bangalore')
GO



INSERT into employee (emp_no, emp_fname, emp_lname, dept_no) 
VALUES 
(10001, 'Matthew', 'Smith', 'd3'),
(10002, 'Elsa', 'Sea', 'd3'),
(10003, 'Albert', 'Lawless', 'd1'),
(10004, 'Gianna', 'Adams', 'd2'),
(10005, 'Henry', 'Lewis', 'd2'),
(10006, 'Joh', 'Bertoni', 'd2'),
(10007, 'Issac', 'Barrimore', 'd1')
GO




INSERT into project (project_no, project_name, budget) 
VALUES 
('p1', 'Apollo', 120000),
('p2', 'Lexus', 95000),
('p3', 'ELC', 186500),
('p2', 'Moo', NULL)
GO



INSERT into works_on (emp_no, project_no, job, enter_date) 
VALUES 
(10002, 'P1', 'Analyst', '2016-10-01'),
(10002, 'P3', 'Manager', '2018-01-01'),
(10001, 'P2', 'Clerk', '2017-02-15'),
(10003, 'P2', 'NULL', '2017-06-01'),
(10004, 'P2', 'NULL', '2016-12-15'),
(10005, 'P3', 'Analyst', '2017-10-15'),
(10006, 'P1', 'Manager', '2017-04-15'),
(10007, 'P1', 'NULL', '2017-08-01'),
(10007, 'P2', 'Clerk', '2017-02-01'),
(10006, 'P3', 'Clerk', '2016-11-15'),
(10004, 'P1', 'Clerk', '2017-01-04')
GO




/* Q6: Create three logins called alpha, beta, and gamma. The corresponding passwords are qwertyuiop!, asdfghjkl!, and zxcvbnm!, respectively.The default database is the SampleDB database. After creating the logins, check their existence using the system catalog. */

CREATE LOGIN alpha
WITH PASSWORD = 'qwertyuiop!', DEFAULT_DATABASE = Sample
GO

CREATE LOGIN beta
WITH PASSWORD = 'asdfghjkl!', DEFAULT_DATABASE = Sample
GO

CREATE LOGIN gamma
WITH PASSWORD = 'zxcvbnm!', DEFAULT_DATABASE = Sample
GO


-- After creating the logins, check their existence using the system catalog

SELECT * FROM master.sys.sql_logins
where default_database_name = 'Sample'
GO



-- Q7: Create three new database usernames for the logins mentioned in Question 6.The new names are s_alpha, s_beta, and s_gamma

CREATE USER s_alpha FOR LOGIN alpha;
GO

CREATE USER s_beta FOR LOGIN beta;
GO

CREATE USER s_gamma FOR LOGIN gamma;
GO



-- Q8: Create a new user-defined database role called admins and add three members to the role. After that, display the information for this role and its members

create role admins
GO

ALTER ROLE admins ADD MEMBER s_alpha
GO

ALTER ROLE admins ADD MEMBER s_beta
GO

ALTER ROLE admins ADD MEMBER s_gamma
GO


-- display the information for this role and its members

SELECT dp.name as RoleName, us.name as UserName 
FROM sys.sysusers us right 
JOIN  sys.database_role_members rm ON us.uid = rm.member_principal_id
JOIN sys.database_principals dp ON rm.role_principal_id =  dp.principal_id



-- Q9: Using the GRANT statement, allow the user s_beta to create tables and the user s_alpha to create stored procedures in the SampleDB database

GRANT CREATE TABLE TO s_beta
GO

GRANT CREATE PROCEDURE TO s_alpha
GO



-- Q10: Using the GRANT statement, allow the user s_gamma to update the columns lname and fname of the employee table

grant update (emp_fname, emp_lname) on employee to s_gamma
GO



-- Q11: Using the GRANT statement, allow the users s_beta and s_alpha to read the values from the columns emp_lname and emp_fname of the employee table

grant select (emp_fname, emp_lname) on employee to s_beta
GO

grant select (emp_fname, emp_lname) on employee to s_alpha
GO



-- Q12: Using the GRANT statement, allow the user-defined role admins to insert new rows in the project table

GRANT INSERT ON project TO admins
GO


-- Q13: Revoke the SELECT rights from the user s_beta

REVOKE SELECT ON SCHEMA :: dbo TO s_beta
GO



-- Q14: Using Transact-SQL,do not allow the user s_alpha to insert the new rows in the project table either directly or indirectly (using roles)

deny insert on project to s_alpha
GO


-- Q15: Display the existing information about the user s_alpha in relation to the SampleDB database

EXECUTE AS USER = 's_alpha';
GO

SELECT * FROM fn_my_permissions('department', 'OBJECT')
GO

SELECT * FROM fn_my_permissions('employee', 'OBJECT')
GO

SELECT * FROM fn_my_permissions('project', 'OBJECT')
GO

SELECT * FROM fn_my_permissions('works_on', 'OBJECT')
GO


select  princ.name
,       princ.type_desc
,       perm.permission_name
,       perm.state_desc
,       perm.class_desc
,       object_name(perm.major_id)
from    sys.database_principals princ
left join
        sys.database_permissions perm
on      perm.grantee_principal_id = princ.principal_id
where name = 's_alpha'

